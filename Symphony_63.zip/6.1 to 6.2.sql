ALTER TABLE SERVER_SETTINGS 
ALTER COLUMN VARVALUE VARCHAR(500)

GO 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TGR_TICKET_ROUTES]')) 
 drop trigger dbo.[TGR_TICKET_ROUTES]

GO
CREATE TRIGGER [dbo].[TGR_TICKET_ROUTES] ON [dbo].[JOB_TICKET_ROUTES] 
FOR INSERT, UPDATE
AS
    DECLARE @SITE         NVARCHAR(10)
    DECLARE @PARENT_SITE  NVARCHAR(10)
    DECLARE @JOB_NO       NVARCHAR(20)
    DECLARE @JOB_SUB_NO   NVARCHAR(3)
    DECLARE @STATUS       NVARCHAR(15)
    DECLARE @FINAL_STATUS NVARCHAR(15)
    DECLARE @JOBID        UNIQUEIDENTIFIER
    DECLARE @TRAN_TYPE    NVARCHAR(20)
    DECLARE @DUE_DATE     DATETIME
    DECLARE @COMPLETED    DATETIME
    DECLARE @UPDATED      DATETIME
    DECLARE @EMAIL        NVARCHAR(255)
    DECLARE @PRIORITY     BIT
    DECLARE @OLIVER       BIT
    DECLARE @NQUEUE       BIT
    DECLARE @ROUTED       BIT
    DECLARE @REVISED      BIT
    DECLARE @BNQUEUE      BIT
    DECLARE @MAX_JOB_SUB_NO NVARCHAR(3)
    DECLARE @PSJOBNO        NVARCHAR(50)
    DECLARE @JOB_TYPE       NVARCHAR(20)
    DECLARE @MSGID          NVARCHAR(50)
    DECLARE @ESTIMATED_HOURS DECIMAL(10, 2)
    DECLARE @ORIG_ESTIMATED_HOURS DECIMAL(10, 2)
    DECLARE @ORIG_DUE_DATE        DATETIME
    DECLARE @BILLED               BIT
    DECLARE @BILLABLE             BIT
    DECLARE @INVOICED             DATETIME

    DECLARE JT_TRIGGER_CURSOR CURSOR FOR 
    SELECT [SITE],JOB_NO,JOB_SUB_NO FROM inserted

    OPEN JT_TRIGGER_CURSOR
    FETCH NEXT FROM JT_TRIGGER_CURSOR INTO @SITE,@JOB_NO,@JOB_SUB_NO
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SELECT @STATUS = [STATUS], 
            @FINAL_STATUS = FINAL_STATUS, 
            @SITE = [SITE], 
            @DUE_DATE=DUE_DATE,
            @PRIORITY=PRIORITY,
            @OLIVER = OLIVER, 
            @COMPLETED = COMPLETED, 
            @UPDATED = UPDATED,
            @NQUEUE  = NQUEUE,
            @PSJOBNO = PSJOBNO,
            @JOB_TYPE = JOB_TYPE,
            @PARENT_SITE = PARENT_SITE,
            @ROUTED = ROUTED,
            @REVISED = REVISED,
            @MSGID = MSGID,
            @BILLABLE = BILLABLE,
            @ESTIMATED_HOURS = ESTIMATED_HOURS,
            @EMAIL = isnull(EMAIL,''), 
            @JOBID=ROUTEGUID,
            @PRIORITY = PRIORITY, 
            @ORIG_ESTIMATED_HOURS = ORIG_ESTIMATED_HOURS,
            @ORIG_DUE_DATE = ORIG_DUE_DATE,
            @BNQUEUE = BNQUEUE
        FROM VWJOBTICKETS WHERE [SITE]=@SITE AND JOB_NO=@JOB_NO AND JOB_SUB_NO=@JOB_SUB_NO
                      
        --Determine the type of transaction that occured (INSERT or UPDATE)
        SET @TRAN_TYPE =  (case when (SELECT COUNT(*) FROM deleted WHERE RGUID=@JOBID)>0 then 'UPDATE' else 'INSERT' end)
        --Update the final status of a job if the final status is not COMPLETED or CANCELLED
        IF NOT @STATUS IN ('COMPLETED','CANCELLED') and @STATUS<>@FINAL_STATUS
        BEGIN
            UPDATE JOB_TICKET_ROUTES WITH (ROWLOCK) SET FINAL_STATUS=@STATUS WHERE [SITE]=@SITE and JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO
        END

        --Do we need a completed date?
        IF @STATUS IN ('COMPLETED','CANCELLED','REVISED','REROUTED') AND @COMPLETED IS NULL
        BEGIN
            --Yes we do
            --Is this a completed job?
            IF @STATUS IN ('COMPLETED')
            BEGIN
               --Yes, then the completed date should be based on the last step completed
               SET @COMPLETED = (SELECT ISNULL(MAX(COMPLETED),GETDATE()) FROM JOB_TICKET_WORKFLOW WITH (NOLOCK) WHERE JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO)                                       
               UPDATE JOB_TICKET_ROUTES WITH (ROWLOCK) SET COMPLETED=@COMPLETED WHERE [SITE]=@SITE and JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO                                              
            END
            ELSE
            BEGIN
               UPDATE JOB_TICKET_ROUTES WITH (ROWLOCK) SET COMPLETED=GETDATE() WHERE [SITE]=@SITE and JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO                                              
            END
        END
        ELSE IF NOT @STATUS IN ('COMPLETED','CANCELLED','REVISED','REROUTED') AND NOT @COMPLETED IS NULL
        BEGIN
           --Yes the completed date needs to be null but is not
           UPDATE JOB_TICKET_ROUTES WITH (ROWLOCK) SET COMPLETED=NULL WHERE [SITE]=@SITE and JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO                                        
        END

        --Do we need to post an archive log entry
        IF @STATUS in ('COMPLETED','CANCELLED')  --AND @SITE=@PARENT_SITE
        BEGIN
           --Yes, Log an archive transaction
           IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='ARCHIVE' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
           BEGIN
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                VALUES (@SITE,'ARCHIVE','JOB_TICKETS',@JOBID,@TRAN_TYPE,GETDATE() )
           END
        END
                    
        --Need to know this this request come thru the WebApplication
        if UPPER(APP_NAME()) <> 'SYMPHONY.INTERLUDE'
        begin

           --Do we need to queue a warning email notification for this site about this job
           IF dbo.QueueToWarning(@SITE,@JOB_TYPE,@MSGID)=1 and @STATUS in ('INTAKE','PENDING') and @STATUS<>@FINAL_STATUS AND DATALENGTH(@MSGID)>0 AND @SITE=@PARENT_SITE AND @ROUTED=0
           BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='WARNING' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                               VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'WARNING',GETDATE() )
             END
           END

           --Do we need to queue an Intake email notification for this site about this job (Only revision 000 generates this message)
           IF dbo.QueueToIntake(@SITE,@JOB_TYPE)=1 and @STATUS in ('INTAKE') and @STATUS<>@FINAL_STATUS AND @SITE=@PARENT_SITE AND @ROUTED=0
           BEGIN
              --Yes, it qualifies, Has this row already been queued
              IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='INTAKE' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
              BEGIN
                 --No, Then create the TRANS_LOG record
                 INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                 VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'INTAKE',GETDATE() )
              END
           END

           --Do we need to queue an Intake email notification for this site about this job (Only revision 000 generates this message)
           IF dbo.QueueToAccepted(@SITE,@JOB_TYPE)=1 and @STATUS in ('PENDING') and @STATUS<>@FINAL_STATUS AND @SITE=@PARENT_SITE AND @ROUTED=0
           BEGIN
              --Yes, it qualifies, Has this row already been queued
              IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='ACCEPTED' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
              BEGIN
                 --No, Then create the TRANS_LOG record
                 INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                 VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'ACCEPTED',GETDATE() )
              END
           END

           --Do we need to queue an completion email notification for this site about this job (only queue if this is the highest revision)
           IF dbo.QueueToCompletion(@SITE,@JOB_TYPE)=1 and @STATUS in ('COMPLETED') AND @SITE=@PARENT_SITE AND @BNQUEUE=0
           BEGIN
              --Yes, it qualifies, Has this row already been queued
              IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='COMPLETED' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
              BEGIN
             --Yes, it qualifies, Has this row already been completed
             IF (SELECT COUNT(JOBGUID) FROM FEEDBACK_REQUESTS WITH(NOLOCK) WHERE JOBGUID = @JOBID) = 0 
             BEGIN 
               --No, Then create the TRANS_LOG record
               INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
               VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'COMPLETED',GETDATE() )
             END 
              END
                          UPDATE JOB_TICKETS WITH (ROWLOCK) SET BNQUEUE=1
                 WHERE SITE=@SITE and JOB_NO=@JOB_NO and JOB_SUB_NO=@JOB_SUB_NO
           END


           --Do we need to queue an cancellation email notification for this site about this job (only queue if this is the highest revision)
           IF dbo.QueueToCancellation(@SITE,@JOB_TYPE)=1 and @STATUS in ('CANCELLED') and @STATUS<>@FINAL_STATUS AND @SITE=@PARENT_SITE  
           BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='CANCELLED' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                               VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'CANCELLED',GETDATE() )
             END

           END

           --Do we need to queue an Intake email notification for this site about this job (Only revision 000 generates this notice)
           IF dbo.QueueToPriority(@SITE,@JOB_TYPE)=1 and @STATUS in ('PENDING') and @STATUS<>@FINAL_STATUS and @PRIORITY=1 AND @SITE=@PARENT_SITE
           BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='PRIORITY' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                               VALUES (@SITE,'EMAIL','JOB_TICKETS',@JOBID,'PRIORITY',GETDATE() )
             END
           END

           --Do we need to queue a completion of routed job request
           IF dbo.QueueToRouted(@PARENT_SITE,@JOB_TYPE)=1 and @STATUS in ('COMPLETED','CANCELLED') and @STATUS<>@FINAL_STATUS  and @SITE<>@PARENT_SITE
           BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='EMAIL' AND TRAN_TYPE='ROUTED' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                       VALUES (@PARENT_SITE,'EMAIL','JOB_TICKETS',@JOBID,'ROUTED',GETDATE() )
             END
           END

                       --Do we need to queue a BIGHAND Export request
           IF dbo.QueueToBIGHAND(@SITE,@JOB_TYPE)=1 and @STATUS in ('COMPLETED','CANCELLED') and @STATUS<>@FINAL_STATUS AND @SITE=@PARENT_SITE
                       BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='BIGHAND' AND TRAN_TYPE='OUTBOUND' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                               VALUES (@SITE,'BIGHAND','JOB_TICKETS',@JOBID,'OUTBOUND',GETDATE() )
             END
           END

                       --Do we need to queue a BIGHAND Export request
           IF dbo.QueueToPfizerGCS(@SITE)=1 and DATALENGTH(RTRIM(@PSJOBNO))>0 and @SITE=@PARENT_SITE
           BEGIN
             --Yes, it qualifies, Has this row already been queued
             IF (SELECT COUNT(ID) FROM TRANS_LOG WHERE TRAN_SERVICE='PFIZER' AND TRAN_TYPE='GCS' AND TRAN_OWNER='JOB_TICKETS' AND TRAN_ROW=@JOBID)=0
             BEGIN
                --No, Then create the TRANS_LOG record
                INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE,TRAN_OWNER,TRAN_ROW,TRAN_TYPE,TRAN_QUEUED)
                               VALUES (@SITE,'PFIZER','JOB_TICKETS',@JOBID,'GCS',GETDATE() )
             END
           END

        END
        FETCH NEXT FROM JT_TRIGGER_CURSOR INTO @SITE,@JOB_NO,@JOB_SUB_NO
    END
    CLOSE JT_TRIGGER_CURSOR
    DEALLOCATE JT_TRIGGER_CURSOR


GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DASH_GET_MAIL_OVERVIEW]')) 
 drop procedure dbo.[DASH_GET_MAIL_OVERVIEW]

GO


CREATE PROCEDURE [dbo].[DASH_GET_MAIL_OVERVIEW] (@SITE AS NVARCHAR(10) ,@FROM DATETIME, @TO DATETIME)
AS
BEGIN
   /*
      Description   :   Returns # of packages received, versus # delivered, and # still pending for a range
      Written By    :   Ruben J. Figueroa
      Written On   :   04/2/2012 
   */
   SELECT   [Status]   =   'Delivered',
         [Totals]   =   ISNULL(SUM(CASE WHEN DELIVERED IS NULL THEN 0 ELSE 1 END), 0)
   FROM   MAIL_DELIVERIES MD WITH(NOLOCK) LEFT JOIN MAIL_RUNS MR WITH(NOLOCK) ON MD.RUNGUID = MR.RUNGUID
   WHERE   created BETWEEN @FROM AND @TO AND MD.[SITE] = @SITE  
   UNION 
   SELECT   [Status]   =   'Pending',
         [Totals]   =   ISNULL(SUM(CASE WHEN DELIVERED IS NULL THEN 1 ELSE 0 END), 0)
   FROM   MAIL_DELIVERIES MD WITH(NOLOCK) LEFT JOIN MAIL_RUNS MR WITH(NOLOCK) ON MD.RUNGUID = MR.RUNGUID
   WHERE   created BETWEEN @FROM AND @TO AND MD.[SITE] = @SITE  

END 

GO


GO
/****** Object:  StoredProcedure [dbo].[UNI_GET_FEEDBACKLEGEND]    Script Date: 08/15/2013 06:10:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[UNI_GET_FEEDBACKLEGEND] (@SITE VARCHAR(10))
AS
BEGIN
	--Written By	:	Sudalai Mani
	--Written On	:	07/15/2013	
	--Description	:	get rank feedback legend	
    SELECT dbo.fn_GetServerVariable ('FEEDBACK_LEGEND')
    
END

GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_GET_JOB_TICKET]')) 
 drop procedure dbo.[UNI_GET_JOB_TICKET]

GO
CREATE PROCEDURE [dbo].[UNI_GET_JOB_TICKET]
@SITE       AS NVARCHAR(10),
@JOB_NO     AS NVARCHAR(10),
@JOB_SUB_NO AS NVARCHAR(3) = '',
@STAFFID    AS NVARCHAR(50) = '',
@IsPrint    AS BIT =0
AS
BEGIN
   --Written By  : Ruben J. Figueroa
   --Written On  : 03/26/2008
   --Description : Gets all the information associated with a job ticket

   --Modified by : Matt de Melo Jr
   --Modified On : 09/04/2008
   --Description : Add select statement #10 to extract project information.

   --Modified by : Matt de Melo Jr
   --Modified On : 03/03/2009
   --Description : Add select statement #12, #13 to extract QC, Feedback information.

   --Modified By : Ruben Figueroa
   --Modified On : 1/12/2010
   --Decription  : Added calculated columns for QC and Feedback Scores
   --            : Removed the site restriction of configuration objects now that we are 
   --            : keep only one base copy of the job ticket

   --Updated On : 7/24/2010 by Ruben Figueroa - Added support for the Archived_Job_Tickets_Labels table
   --Updated On : 3/12/2012 by Ruben Figueroa - Added support for smart/conditional sorting which is based on the staff id provide in the command line
   --                                  The way smart sorting works is that based on the staff id, it will try to diff that persons task to the top of the list
   --                                           based on the following conditions:
   --                                           0 - Staff member is on task and task is active
   --                                           1 - Staff member is on task and task is not started
   --                                           2 - Staff member is on task and task is completed
   --                                           3 - Not staff members task or no task member provided
   --                                           
   --                                           The ordering for the results in then based on smart sort score, step no, and row id
   
   

   --Do we have a site?
   IF DATALENGTH(RTRIM(@SITE))=0 
   BEGIN
      RAISERROR ('SITE IS REQUIRED!', 10, 1)
      RETURN
   END

   --Do we have a job number?
   IF DATALENGTH(RTRIM(@JOB_NO))=0 
   BEGIN
      RAISERROR ('JOB NUMBER IS REQUIRED!', 10, 1)
      RETURN
   END

   ----Do we have a job revision number?
   --IF DATALENGTH(RTRIM(@JOB_SUB_NO))=0 
   --BEGIN
   --    SET @JOB_SUB_NO=(SELECT TOP 1 JT.JOB_SUB_NO FROM VWJOBTICKETS JT WITH (NOLOCK)
   --      WHERE JT.[SITE]=@SITE AND JT.JOB_NO = @JOB_NO
   --      ORDER BY JT.JOB_SUB_NO DESC)
   --END
   
   --0) First the ticket information
   SELECT *,
     SLA_DATE=DATEADD(N,DBO.FN_CLIENTSLA(JT.SITE,JT.JOB_TYPE,JT.NO_SETS,JT.NO_ORIGINALS,JT.RUSH), REQUESTED_DATE),QCSCORE=ISNULL(dbo.fn_CalculateQCScoreForJob(JT.JOBGUID),-1), FBSCORE=ISNULL(dbo.fn_CalculateFBScoreForJob(JT.ROUTEGUID),-1) 
      FROM VWJOBTICKETS JT WITH (NOLOCK)
      WHERE JT.SITE=@SITE AND JT.JOB_NO = @JOB_NO  
      --AND JT.JOB_SUB_NO = @JOB_SUB_NO

   --1) Now Job Type information
   SELECT JT.*,ADDRLABEL=S.COMMENTS,SJT.SLA_TIME 
      FROM JOB_TICKET_TYPES JT WITH (NOLOCK)
      JOIN SITES S WITH (NOLOCK) ON S.SITE=JT.SITE 
      JOIN SITE_JOB_TYPES SJT ON JT.[SITE] = SJT.[SITE] AND JT.job_type = SJT.job_type
      WHERE JT.JOB_NO = @JOB_NO  
      --AND JT.JOB_SUB_NO = @JOB_SUB_NO

   --2) Now the fields in the table the job ticket is using   
         SELECT * 
            FROM JOB_TICKET_HEADERS WITH (NOLOCK) 
            WHERE JOB_NO =@JOB_NO 
            --AND JOB_SUB_NO = @JOB_SUB_NO
            ORDER BY YPOS, XPOS        
   
   --3) Now the categories for the job ticket
   select C.*,
      OPTIONS=(SELECT COUNT(O.ID) FROM job_ticket_options O WITH (nolock) WHERE O.JOB_NO =C.JOB_NO AND O.JOB_SUB_NO = C.JOB_SUB_NO AND O.CATEGORY=C.CATEGORY),
      IMAGES=(SELECT COUNT(O.ID) FROM job_ticket_options O WITH (nolock) WHERE O.JOB_NO =C.JOB_NO AND O.JOB_SUB_NO = C.JOB_SUB_NO AND O.CATEGORY=C.CATEGORY AND NOT O.[SPIGUID] IS NULL)
      from job_ticket_categories C WITH (nolock) 
      where C.JOB_NO =@JOB_NO 
      --AND C.JOB_SUB_NO = @JOB_SUB_NO
      ORDER BY C.CATEGORY, C.SORDER

   --4) Now the options for the job ticket
   select * 
      from job_ticket_options WITH (nolock) 
      where JOB_NO =@JOB_NO 
      --AND JOB_SUB_NO = @JOB_SUB_NO
      ORDER BY CATEGORY, SORDER

   --5) Now the tasks for the job ticket
   select *, [UNIT_COST]=0 from job_ticket_tasks WITH (nolock) 
      where JOB_NO=@JOB_NO 
      --AND JOB_SUB_NO = @JOB_SUB_NO

   --6) Now the work flow for the job
   select distinct JS.*, 
      RESOURCE_NAME=dbo.fn_GetResource(RESOURCE), 
      PERSON=dbo.fn_GetPersonnel(PERSONNEL), 
      LINECOST  =ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD, JS.PROCESS_RATE, HOURS, UNIT_COST, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      LINECOST_B=ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,HOURS, UNIT_COST_B, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      LINECOST_C=ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,HOURS, UNIT_COST_C, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      LINECOST_D=ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,HOURS, UNIT_COST_D, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      LINECOST_E=ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,HOURS, UNIT_COST_E, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      LINECOST_F=ISNULL([dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,HOURS, UNIT_COST_F, QUANTITY),0) * (1 + ISNULL(MARKUP,0)/100.0),
      QCSCORE,
      METHOD01=ISNULL(JT.METHOD01, ''),
      CUSTOM01=ISNULL(JT.CUSTOM01, ''),
      VALUE01 =ISNULL(JS.VALUE01, ''),
      METHOD02=ISNULL(JT.METHOD02, ''),
      CUSTOM02=ISNULL(JT.CUSTOM02, ''),
      VALUE02 =ISNULL(JS.VALUE02, ''),
      METHOD03=ISNULL(JT.METHOD03, ''),
      CUSTOM03=ISNULL(JT.CUSTOM03, ''),
      VALUE03 =ISNULL(JS.VALUE03, '')
   FROM (
      SELECT 
         --W.*, 
         W.[ID] ,W.[RGUID] ,W.[SITE] ,W.[JOB_NO] ,W.[JOB_SUB_NO] ,W.[STEP_NO] ,W.[STEP_NAME]
      ,W.[SCHEDULED] ,W.[STARTED] ,W.[COMPLETED] ,W.[COST_CODE] ,W.[UNIT_COST] ,W.[PROCESS_RATE] ,W.[PROCESS_METHOD] ,W.[RESOURCE]
      ,W.[START_METER] ,W.[END_METER] ,W.[WASTE_METER] ,W.[PERSONNEL] ,W.[EST_HRS] ,W.[EST_QTY] ,W.[HOURS] ,W.[QUANTITY]
      ,W.[SLIDE01] ,W.[SLIDE02] ,W.[SLIDE03] 
      ,W.[COMMENTS] 
      ,W.[CREATED] ,W.[CREATED_BY]
      ,W.[UPDATED] ,W.[UPDATED_BY] ,W.[PASSED] ,W.[ROW_TYPE] ,W.[SIDES] ,W.[PAPER_TYPES] ,W.[RESOURCE_RQ]
      ,W.[PERSON_RQ] ,W.[ISMANUAL] ,W.[ISMETERED] ,W.[ISCOLOR] ,W.[ISSCHEDULED]
      ,W.[ROLLOVER] ,W.[BILLABLE] ,W.[BILLED] ,W.[LEVELGUID] --,W.[RQ_TIME] 
      ,W.[SMC_SLIDES]--,W.[MANDITORY] 
      ,W.[DEADLINE] ,W.[UNIT_COST_B] ,W.[UNIT_COST_C] ,W.[UNIT_COST_D] ,W.[UNIT_COST_E] ,W.[UNIT_COST_F]
      ,W.[VALUE01] ,W.[ISQA] ,W.[ISDLY] ,W.[ISREQUIRED] ,W.[VALUE02] ,W.[VALUE03] ,W.[MARKUP],
         J.STATUS,
         RunTime=(CASE WHEN EST_HRS>0 THEN EST_HRS * 60 ELSE dbo.fn_EstimateRunTimeForResource(J.SITE, W.RESOURCE, J.GRADE, J.NO_ORIGINALS, J.NO_SETS) END), 
         SLA    =(CASE WHEN EST_HRS>0 THEN EST_HRS * 60 ELSE dbo.fn_CalculateStepSLA(J.SITE,J.JOB_NO, J.JOB_SUB_NO, W.STEP_NO, J.NO_SETS, J.NO_ORIGINALS) END ),
         QCSCORE=ISNULL(dbo.fn_CalculateQCScoreForTask(W.RGUID),-1),
         TASKORDER=CASE 
                   WHEN DATALENGTH(RTRIM(W.PERSONNEL))>0 AND W.PERSONNEL=@STAFFID AND NOT W.[STARTED] IS NULL AND W.COMPLETED IS NULL THEN 0
                   WHEN DATALENGTH(RTRIM(W.PERSONNEL))>0 AND W.PERSONNEL=@STAFFID AND W.[STARTED] IS NULL THEN 1
                   WHEN DATALENGTH(RTRIM(W.PERSONNEL))>0 AND W.PERSONNEL=@STAFFID AND NOT W.[STARTED] IS NULL AND NOT W.COMPLETED IS NULL THEN 2
                   ELSE 3
                 END                  
         FROM JOB_TICKET_WORKFLOW W WITH (NOLOCK) 
         JOIN VWJOBTICKETS J WITH (NOLOCK) ON J.SITE=W.SITE AND J.JOB_NO=W.JOB_NO AND J.JOB_SUB_NO=W.JOB_SUB_NO
         WHERE W.[SITE]=@SITE AND W.JOB_NO =@JOB_NO AND W.JOB_SUB_NO = @JOB_SUB_NO AND W.ROW_TYPE IN ('P', 'R', 'W')
   ) AS JS 
   left outer join job_ticket_tasks JT WITH (nolock) ON JT.JOB_NO=JS.JOB_NO AND JT.STEP_NO=JS.STEP_NO
   order by 
      TASKORDER,
      STEP_NO,
      ID

   --7) Now the charges only records
   select distinct JS.*, LINECOST=ISNULL(UNIT_COST * QUANTITY * (1 + MARKUP/100.0), 0)
      from job_ticket_workflow JS WITH (nolock) 
      where JS.[SITE]=@SITE AND JS.JOB_NO =@JOB_NO AND JS.JOB_SUB_NO = @JOB_SUB_NO AND ROW_TYPE IN ('C')
      order by id,step_no

   --8) Now the notes for the job
   SELECT CREATED, CREATED_BY, COMMENTS FROM JOB_TICKET_NOTES WITH (NOLOCK) 
      where JOB_NO =@JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO
      order by CREATED

   --9) Now the completed work attached to the job
   select *
      from job_ticket_attachments with (nolock) 
      where JOB_NO =@JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO and intake=0 

   --10) Now the vendors job was send to
   select *, LINE_COST = ROUND(COST * (1 + MARKUP/100.0),2)
      from job_ticket_vended with (nolock) 
      where [SITE]=@SITE AND JOB_NO =@JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO
      order by vendor, vended, invoice_no, line_no

   --11) Now the project information
   SELECT [PROJECT]=P.[PROJECT_NO] + '-' + P.[PROJECT_REV] 
      FROM JOB_TICKET_ROUTES J 
      JOIN PROJECTS P WITH (NOLOCK) ON J.[PRJGUID] = P.[PRJGUID]
      WHERE J.[SITE]=@SITE AND J.[JOB_NO] =@JOB_NO AND J.[JOB_SUB_NO] = @JOB_SUB_NO AND DATALENGTH(RTRIM(J.PRJGUID))>0

   --12) Now projects
   SELECT [PRJGUID], [PROJECT_NO], [PROJECT_REV], [STATUS],[COMPLETED]
      FROM PROJECTS WITH (NOLOCK)
      WHERE [SITE]=@SITE AND [COMPLETED] IS NULL

   --13) Now QC
   SELECT JC.*
      FROM JOB_TICKETS JT WITH (NOLOCK)
         JOIN JOB_TICKET_QC  JC 
            ON JT.[RGUID]=JC.[JOBGUID] 
      WHERE JT.[SITE]=@SITE 
         AND JT.[JOB_NO]=@JOB_NO 
         AND JT.[JOB_SUB_NO]=@JOB_SUB_NO
      ORDER BY JC.[SORDER]

   --14)Now Feedback
   SELECT F.*
      FROM vwJOBTICKETS JT WITH (NOLOCK)
         JOIN FEEDBACK_RESULTS F 
            ON JT.[ROUTEGUID]=F.[JOBGUID]
      WHERE JT.[SITE]=@SITE 
         AND JT.[JOB_NO]=@JOB_NO 
         AND JT.[JOB_SUB_NO]=@JOB_SUB_NO
      ORDER BY F.[SORDER]

   --15)Now Feedback requests
   SELECT [FBGUID], [RESPONDED],[RESPONSE_PROVIDED]
      FROM vwJOBTICKETS JT WITH (NOLOCK)
         JOIN  FEEDBACK_REQUESTS F
            ON JT.[JOBGUID]=F.[JOBGUID]
      WHERE JT.[SITE]=@SITE 
         AND JT.[JOB_NO]=@JOB_NO 
         AND JT.[JOB_SUB_NO]=@JOB_SUB_NO

   --16) Routed steps
   SELECT
      j.site,
      j.status,
      j.job_no,
      j.job_sub_no,
      jo.Step_no,
      jo.Step_name,
      staff_member=isnull(dbo.fn_GetPersonnelName(jo.personnel),''),
      jo.started,
      jo.completed,
      j.NO_SETS, 
      jo.hours,
      jo.ismetered,
      jo.quantity,
        j.deadline,
      LINECOST  =ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST, jo.QUANTITY),0),
      LINECOST_B=ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST_B, jo.QUANTITY),0),
      LINECOST_C=ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST_C, jo.QUANTITY),0),
      LINECOST_D=ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST_D, jo.QUANTITY),0),
      LINECOST_E=ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST_E, jo.QUANTITY),0),
      LINECOST_F=ISNULL([dbo].[fn_CalculateCost](jo.PROCESS_METHOD, jo.PROCESS_RATE, jo.HOURS, jo.UNIT_COST_F, jo.QUANTITY),0)
      ,jo.rguid
     from 
        vwjobtickets j  WITH (nolock)
        JOIN job_ticket_workflow jo WITH (nolock) ON j.job_no=jo.job_no and j.job_sub_no=jo.job_sub_no and j.site=jo.site
     where 
        j.job_no=@JOB_NO and 
        j.ROUTED=1 AND
        J.SITE <> @SITE 
        AND JO.ROW_TYPE IN ('W')
      ORDER BY jo.STEP_NO

   --17) Now the notes for the job
   SELECT * FROM JOB_TICKET_AUDITS WITH (NOLOCK) 
      where JOB_NO=@JOB_NO
      order by UPDATED

   --18) Now the label configuration data
   SELECT LBLS.*
      FROM JOB_TICKET_LABELS LBLS WITH (NOLOCK)
      WHERE LBLS.[JOB_NO]=@JOB_NO 

END

GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_GET_JOB_TICKET_WORKFLOW]')) 
 drop procedure dbo.[UNI_GET_JOB_TICKET_WORKFLOW]

GO
CREATE PROCEDURE [dbo].[UNI_GET_JOB_TICKET_WORKFLOW]
@SITE       AS NVARCHAR(10),
@JOB_NO     AS NVARCHAR(10),
@JOB_SUB_NO AS NVARCHAR(3)='',
@STAFFID    AS NVARCHAR(50) = ''
AS
BEGIN

   --Written By : Ruben J. Figueroa
   --Written On : 03/26/2008
   --Description: Get the workflow information associated with a job ticket
   --Updated By : Ruben J. Figueroa On 01/26/2012, updated to include information to execute
   --                                              the update of the tally sections of the job update module
   --Updated On : 3/12/2012 by Ruben Figueroa - Added support for smart/conditional sorting which is based on the staff id provide in the command line
   --                                  The way smart sorting works is that based on the staff id, it will try to diff that persons task to the top of the list
   --                                           based on the following conditions:
   --                                           0 - Staff member is on task and task is active
   --                                           1 - Staff member is on task and task is not started
   --                                           2 - Staff member is on task and task is completed
   --                                           3 - Not staff members task or no task member provided
   --                                           
   --                                           The ordering for the results in then based on smart sort score, step no, and row id
   --
   --Updated On : 5/3/2012 by Ruben Figueroa - Added the description name for the levelguid value

   --Do we have a site?
   IF DATALENGTH(RTRIM(@SITE))=0 
   BEGIN
      RAISERROR ('SITE IS REQUIRED!', 10, 1)
      RETURN
   END

   --Do we have a job number?
   IF DATALENGTH(RTRIM(@JOB_NO))=0 
   BEGIN
      RAISERROR ('JOB NUMBER IS REQUIRED!', 10, 1)
      RETURN
   END

   --Do we have a job revision number?
   IF DATALENGTH(RTRIM(@JOB_SUB_NO))=0 
   BEGIN
      SET @JOB_SUB_NO=(SELECT TOP 1 JT.JOB_SUB_NO FROM VWJOBTICKETS JT WITH (NOLOCK)
         WHERE JT.[SITE]=@SITE AND JT.JOB_NO = @JOB_NO
         ORDER BY JT.JOB_SUB_NO DESC)
   END

   -- Now the work flow for the job current site
   select * from
   (
      select distinct JS.*, 
         RESOURCE_NAME=dbo.fn_GetResource(JS.RESOURCE), 
         PERSON    =dbo.fn_GetPersonnel(JS.PERSONNEL),
         STAFF_ROLE=dbo.fn_GetPersonnelLevel(JS.LEVELGUID),
         METHOD01=ISNULL(JT.METHOD01, ''),
         CUSTOM01=ISNULL(JT.CUSTOM01, ''),
         --VALUE01 =ISNULL(JS.VALUE01, ''),
         METHOD02=ISNULL(JT.METHOD02, ''),
         CUSTOM02=ISNULL(JT.CUSTOM02, ''),
         --VALUE02 =ISNULL(JS.VALUE02, ''),
         METHOD03=ISNULL(JT.METHOD03, ''),
         CUSTOM03=ISNULL(JT.CUSTOM03, ''),
         --VALUE03 =ISNULL(JS.VALUE03, ''),
         LINECOST  =[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST,   JS.QUANTITY),
         LINECOST_B=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_B, JS.QUANTITY),
         LINECOST_C=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_C, JS.QUANTITY),
         LINECOST_D=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_D, JS.QUANTITY),
         LINECOST_E=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_E, JS.QUANTITY),
         LINECOST_F=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_F, JS.QUANTITY),
         QCSCORE   =ISNULL(dbo.fn_CalculateQCScoreForTask(JS.RGUID),-1),
         TASKORDER=CASE 
                   WHEN DATALENGTH(RTRIM(JS.PERSONNEL))>0 AND JS.PERSONNEL=@STAFFID AND NOT JS.[STARTED] IS NULL AND JS.COMPLETED IS NULL THEN 0
                   WHEN DATALENGTH(RTRIM(JS.PERSONNEL))>0 AND JS.PERSONNEL=@STAFFID AND JS.[STARTED] IS NULL THEN 1
                   WHEN DATALENGTH(RTRIM(JS.PERSONNEL))>0 AND JS.PERSONNEL=@STAFFID AND NOT JS.[STARTED] IS NULL AND NOT JS.COMPLETED IS NULL THEN 2
                   ELSE 3
                 END                  
         from 
            job_ticket_workflow JS WITH (nolock) 
            left outer join job_ticket_tasks JT WITH (nolock) ON JT.JOB_NO=JS.JOB_NO AND JT.STEP_NO=JS.STEP_NO
         where JS.[SITE]=@SITE AND JS.JOB_NO =@JOB_NO AND JS.JOB_SUB_NO = @JOB_SUB_NO AND JS.ROW_TYPE IN ('P','R','W')
   ) workflow
   order by 
      TASKORDER,
      STEP_NO,
      ID

   -- Now the work flow for the job steps that have been routed
   select distinct JS.*, 
      RESOURCE_NAME=dbo.fn_GetResource(JS.RESOURCE), 
      PERSON  =dbo.fn_GetPersonnel(JS.PERSONNEL),
      STAFF_ROLE=dbo.fn_GetPersonnelLevel(JS.LEVELGUID),
      METHOD01=ISNULL(JT.METHOD01, ''),
      CUSTOM01=ISNULL(JT.CUSTOM01, ''),
      --VALUE01 =ISNULL(JS.VALUE01, ''),
      METHOD02=ISNULL(JT.METHOD02, ''),
      CUSTOM02=ISNULL(JT.CUSTOM02, ''),
      --VALUE02 =ISNULL(JS.VALUE02, ''),
      METHOD03=ISNULL(JT.METHOD03, ''),
      CUSTOM03=ISNULL(JT.CUSTOM03, ''),
      --VALUE03 =ISNULL(JS.VALUE03, ''),
      LINECOST  =[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST,   JS.QUANTITY),
      LINECOST_B=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_B, JS.QUANTITY),
      LINECOST_C=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_C, JS.QUANTITY),
      LINECOST_D=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_D, JS.QUANTITY),
      LINECOST_E=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_E, JS.QUANTITY),
      LINECOST_F=[dbo].[fn_CalculateCost](JS.PROCESS_METHOD,JS.PROCESS_RATE,JS.HOURS, JS.UNIT_COST_F, JS.QUANTITY),
      QCSCORE   =ISNULL(dbo.fn_CalculateQCScoreForTask(JS.RGUID),-1)
      from 
         job_ticket_workflow JS WITH (nolock) 
         left outer join job_ticket_tasks JT WITH (nolock) ON JT.JOB_NO=JS.JOB_NO AND JT.STEP_NO=JS.STEP_NO
      where JS.JOB_NO =@JOB_NO AND JS.JOB_SUB_NO = @JOB_SUB_NO AND JS.ROW_TYPE IN ('P','R','W') AND JS.[SITE]<>@SITE
      order by step_no, id

   --Get the base job ticket information only
   select 
      [started], 
      [personnel],
      QCSCORE=ISNULL(dbo.fn_CalculateQCScoreForJob(JOBGUID),-1), 
      FBSCORE=ISNULL(dbo.fn_CalculateFBScoreForJob(ROUTEGUID),-1) 
   from vwjobtickets 
   where [SITE]=@SITE and JOB_NO=@JOB_NO AND JOB_SUB_NO=@JOB_SUB_NO

END
GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_GET_JOB_UNUSED_FIELDS]')) 
 drop procedure dbo.[UNI_GET_JOB_UNUSED_FIELDS]

GO
CREATE PROCEDURE [dbo].[UNI_GET_JOB_UNUSED_FIELDS]
   @SITE      VARCHAR(20),
   @JOBTYPE   VARCHAR(20)
AS 
BEGIN 
   --Name         :   UNI_GET_JOB_UNUSED_FIELDS
   --Written By   :   Matt de Melo Jr
   --Written On   :   05/07/2008
   --Description   :   Gets job configuration based on the site and job code given
   --Modified By   :   Matt de Melo Jr
   --Modified On   :   07/15/2010
   --Description   :   Added a check for decimal datatype fields to take one char on length

   --Do we have a site?
   IF DATALENGTH(RTRIM(@SITE)) = 0 
   BEGIN
      RAISERROR ('SITE IS REQUIRED!', 16, 1)
      RETURN
   END 
   
   --Do we have a project code?
   IF DATALENGTH(RTRIM(@JOBTYPE)) = 0 
   BEGIN
      RAISERROR ('JOB TYPE IS REQUIRED!', 16, 1)
      RETURN
   END 
   
   --Do we have a project type?
   IF NOT EXISTS(SELECT ID FROM SITE_JOB_TYPES JT WITH(NOLOCK) WHERE JT.[SITE] = @SITE AND JT.JOB_TYPE = @JOBTYPE)
      RETURN
   
   --Get System Columns
   SELECT   * 
   FROM   (SELECT   DISTINCT [Column_name]   =   SUBSTRING(c.name, 1, 32), 
               [Column_type]         =   TYPE_NAME(c.xtype), 
               [Column_length]         =   CASE WHEN TYPE_NAME(c.xtype) = 'decimal' THEN c.[length] - 1 ELSE c.[length] END 
         FROM   sysobjects o JOIN syscolumns c ON c.id = o.id 
         WHERE   o.name IN ('job_tickets', 'job_ticket_jtinfo')
         ) fields 
   WHERE   [Column_name] NOT IN (SELECT JT.FIELD FROM SITE_JOB_HEADERS JT WITH(NOLOCK) 
         WHERE JT.[SITE] = @SITE AND JT.JOB_TYPE = @JOBTYPE) AND [Column_name] NOT IN 
         ('ID', 'RGUID', 'SITE', 'PARENT_SITE', 'JOB_TYPE', 'INVOICE_NO', 'INVOICED', 'INVOICE_AMT', 'NQUEUE', 
         'NQ_METER_CNT', 'STATUS', 'LAST_STEP', 'COMPLETED', 'TRACK_WORKFLOW', 'UPDATED', 'JOB_SUB_NO', 'QUANTITY', 'SCHEDULED', 
         'PPM', 'CPP', 'PLU', 'SHIFT', 'RATE', 'CREATED', 'CREATED_BY', 'STARTED', 'RESOURCE', 'PERSONNEL', 'BATES_01', 'BATES_02', 
         'START_METER', 'END_METER', 'WASTE_METER', 'ORIG_JOB_NO', 'VENDED', 'VENDED_READY', 'VENDED_COST', 'SHIPPED', 'SHIP_VIA', 
         'SHIP_COST', 'BOSS', 'UPDATED_BY', 'SETUP_TIME', 'CLEANUP_TIME', 'REQUESTED_TIME', 'DUE_TIME', 'ORIG_DUE_DATE', 'ORIG_DUE_TIME', 
         'QA_BY', 'QA_DATE', 'QA_PASSED', 'BNQUEUE', 'OLIVER', 'NON_PRODUCTION', 'OWNER', 'ACCEPTED_BY', 'ACCEPTED_DATE', 'COMMENTS', 
         'CLOSED', 'ROUTED', 'REVISED', 'BILLED', 'BILLABLE', 'FINAL_STATUS', 'PRJGUID', 'ROUTE_LIMITED', 'MSGID', 'VENDOR_INVOICE_NO', 
         'VENDED_TO', 'NOT_BILLABLE')
   
   END 

GO

GO
/****** Object:  StoredProcedure [dbo].[UNI_GET_SUPPORTDETAILS]    Script Date: 08/15/2013 06:10:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[UNI_GET_SUPPORTDETAILS] (@SITE NVARCHAR(20))
AS
BEGIN
	/*
		Name		:   UNI_GET_SUPPORTDETAILS
		Description	:   Returns support contact details
		Written On	:	07/15/2013 By Sudalai Mani		
	*/   
    
    SELECT [Email] = dbo.fn_GetServerVariable ('SUPPORT_EMAIL'), [Phone] = dbo.fn_GetServerVariable ('SUPPORT_PHONE')

END

GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_INSERT_DUPLICATE_TASK]')) 
 drop procedure dbo.[UNI_INSERT_DUPLICATE_TASK]

GO

CREATE PROCEDURE [dbo].[UNI_INSERT_DUPLICATE_TASK] 
@Site      VARCHAR(50),
@OldJobNo   VARCHAR(50),
@NewJobNo   VARCHAR(50),
@User      VARCHAR(50)
AS 
BEGIN 
   /*
      Written By   :   Sudalai Mani
      Written On   :   03/21/2013
      Description   :   Duplicate the workflow
      Updated By   :   Sudalai Mani on 08/08/2013, Added cost code column
   */
   
   --Do we have a site?
   IF DATALENGTH(RTRIM(@SITE)) = 0 
   BEGIN
      RAISERROR ('SITE IS REQUIRED!', 10, 1)
      RETURN
   END

   --Do we have a old job number?
   IF DATALENGTH(RTRIM(@OldJobNo)) = 0 
   BEGIN
      RAISERROR ('OLD JOB NUMBER IS REQUIRED!', 10, 1)
      RETURN
   END 
   
   --Do we have a new job number?
   IF DATALENGTH(RTRIM(@NewJobNo)) = 0 
   BEGIN
      RAISERROR ('NEW JOB NUMBER IS REQUIRED!', 10, 1)
      RETURN
   END
   
   --Do we have a user?
   IF DATALENGTH(RTRIM(@USER)) = 0 
   BEGIN
      RAISERROR ('USER IS REQUIRED!', 10, 1)
      RETURN
   END
   
   SET @OldJobNo = SUBSTRING(@OldJobNo, 1, 10)
   SET @NewJobNo = SUBSTRING(@NewJobNo, 1, 10)
   
   IF EXISTS(SELECT JOB_NO FROM JOB_TICKET_WORKFLOW WITH(NOLOCK) WHERE JOB_NO = @OldJobNo AND [SITE] = @Site)
   BEGIN 
      DELETE FROM JOB_TICKET_WORKFLOW WHERE JOB_NO = @NewJobNo AND [SITE] = @Site
      INSERT INTO JOB_TICKET_WORKFLOW ([SITE], JOB_NO, JOB_SUB_NO, STEP_NO, STEP_NAME, UNIT_COST,
               UNIT_COST_B, UNIT_COST_C, UNIT_COST_D, UNIT_COST_E, UNIT_COST_F, PROCESS_RATE, PROCESS_METHOD, 
               CREATED, CREATED_BY, UPDATED, UPDATED_BY, PASSED, ROW_TYPE, MARKUP, PAPER_TYPES, 
               RESOURCE_RQ, PERSON_RQ, ISREQUIRED, ISMANUAL, ISSCHEDULED, ISMETERED, ISCOLOR, ISQA, ISDLY, 
               SMC_SLIDES, ROLLOVER, BILLABLE, BILLED, COST_CODE)
      SELECT   [SITE], @NewJobNo, '000', STEP_NO, STEP_NAME, UNIT_COST, UNIT_COST_B, UNIT_COST_C, 
            UNIT_COST_D, UNIT_COST_E, UNIT_COST_F, PROCESS_RATE, PROCESS_METHOD, GETDATE(), @User, GETDATE(), 
            @User, PASSED, ROW_TYPE, MARKUP, PAPER_TYPES, RESOURCE_RQ, PERSON_RQ, ISREQUIRED, ISMANUAL, 
            ISSCHEDULED, ISMETERED, ISCOLOR, ISQA, ISDLY, SMC_SLIDES, ROLLOVER, BILLABLE, BILLED, COST_CODE 
      FROM   JOB_TICKET_WORKFLOW WITH(NOLOCK) 
      WHERE   JOB_NO = @OldJobNo AND [SITE] = @Site AND ROW_TYPE = 'W' 
   END    
   
END 
GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_UPDATE_FEEDBACK_REQUESTS]')) 
 drop procedure dbo.[UNI_UPDATE_FEEDBACK_REQUESTS]

GO
CREATE PROCEDURE [dbo].[UNI_UPDATE_FEEDBACK_REQUESTS]
   @FBGUID     NVARCHAR(50),
   @JOBGUID    NVARCHAR(50),
   @RESPONDED   DATETIME,
   @RESPONSE   NVARCHAR(1),
   @SITE       NVARCHAR(20),
   @USER       NVARCHAR(50),
   @URL      NVARCHAR(255)
AS
BEGIN
   /*
      Name      :   UNI_UPDATE_FEEDBACK_REQUESTS
      Description   :   Update feedback requests based on job guid and feedback request given.
      Written On   :   02/13/09
      Written By   :   Matt. de Melo Jr.
      Updated On   :   10/02/2009
      Updated By   :   M. de Melo Jr.
      Version     :   Symphony 4.3.5
      Description   :   convertion of rank field answer could not be done when row is empty, a check had to be perform in order to fix it.
   */
   
   --Do we have a request id?
   IF DATALENGTH(RTRIM(@FBGUID)) = 0 
   BEGIN
      RAISERROR ('Job feedback request ID is required!', 16, 1)
      RETURN
   END 
   
   --Do we have a site?
   IF DATALENGTH(RTRIM(@SITE)) = 0 
   BEGIN
      RAISERROR ('Site is required!', 16, 1)
      RETURN
   END 
   
   --Do we have a job id?
   IF DATALENGTH(RTRIM(@JOBGUID)) = 0 
   BEGIN
      RAISERROR ('Job ID is required!', 16, 1)
      RETURN
   END

   --Get the site, low score notice point, and score on the job
    DECLARE @LOWSCORE DECIMAL(10, 2)
    DECLARE @FSCORE   DECIMAL(10, 2)

    SET @LOWSCORE = CONVERT(DECIMAL(10, 2), dbo.fn_GetSystemVariable(@SITE, 'FEEDBACK_LOW_SCORE')) 
    SET @FSCORE   = (SELECT MIN(CONVERT(DECIMAL(10, 2), CASE WHEN DATALENGTH(RTRIM(ANSWER)) > 0 THEN ANSWER ELSE 0 END)) 
               FROM FEEDBACK_RESULTS WITH(NOLOCK) WHERE FBGUID = @FBGUID AND METHOD = 'RANK')

   --Store job request updated info
   BEGIN TRANSACTION UPDATE_FEEDBACK_REQUESTS
      UPDATE   FEEDBACK_REQUESTS WITH(ROWLOCK) 
      SET      [RESPONDED] = @RESPONDED, [RESPONSE_PROVIDED] = @RESPONSE
      WHERE   [FBGUID] = @FBGUID
      
      IF @@ERROR <> 0
      BEGIN
         ROLLBACK TRAN UPDATE_FEEDBACK_REQUESTS
         RETURN
      END
      
      --Do we need to send a low score notice
      IF @FSCORE <= @LOWSCORE AND @RESPONSE = 'Y'
      BEGIN
            --Log a log score notice
            INSERT INTO TRANS_LOG (TRAN_SITE, TRAN_SERVICE, TRAN_OWNER, TRAN_ROW, TRAN_TYPE, TRAN_QUEUED)
            VALUES (@SITE, 'EMAIL', 'JOB_TICKETS', @JOBGUID, 'FEEDBACK', GETDATE())         
         
         IF @@ERROR <> 0
         BEGIN
            ROLLBACK TRAN UPDATE_FEEDBACK_REQUESTS
            RETURN
         END
      END      
      
      -- Write logs
      INSERT INTO EVENTS ([SITE], [USER], [URL], [COMMENTS]) 
        VALUES (@SITE, @USER, @URL, 'FEEDBACK REQUEST FOR JOB ID ' + @JOBGUID + ' SITE ' +  @SITE + ' HAS BEEN COMPLETED.')
      
      IF @@ERROR <> 0
      BEGIN
         ROLLBACK TRAN UPDATE_FEEDBACK_REQUESTS
         RETURN
      END 
      
   COMMIT TRANSACTION UPDATE_FEEDBACK_REQUESTS

END


GO

GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UNI_UPDATE_JOB_WORKFLOW]')) 
 drop procedure dbo.[UNI_UPDATE_JOB_WORKFLOW]

GO
CREATE PROCEDURE [dbo].[UNI_UPDATE_JOB_WORKFLOW]
   @ID INT
,@SCHEDULED DATETIME
,@DEADLINE DATETIME
,@STARTED DATETIME
,@COMPLETED DATETIME
,@COST_CODE VARCHAR(50)
,@RESOURCE VARCHAR(50)
,@START_METER INT
,@END_METER INT
,@WASTE_METER INT
,@QA VARCHAR(1)
,@PERSONNEL VARCHAR(50)
,@LEVELGUID VARCHAR(50)
,@HOURS DECIMAL(18, 2)
,@QUANTITY DECIMAL(18, 2)
,@SLIDE01 DECIMAL(18, 2)
,@SLIDE02 DECIMAL(18, 2)
,@SLIDE03 DECIMAL(18, 2)
,@SIDES SMALLINT
,@PAPER_TYPE VARCHAR(50)
,@VALUE01 VARCHAR(50)
,@VALUE02 VARCHAR(50)
,@VALUE03 VARCHAR(50)
,@COMMENTS VARCHAR(2048)
,@USER VARCHAR(50)
,@URL VARCHAR(255)
AS
BEGIN
   --Written By   :   Ruben J. Figueroa
    --Written On   :   05/13/2008
    --Description   :   Updates an existing job workflow record
    --Modified by   :   Matt de Melo Jr
    --Modified On   :   08/28/2008
    --Description   :   Added QA field to be insert in the table.
   --Modified On   :   05/02/2013 Sudalai Mani - Increase the length of fields
   --Description   :   Included the parent site for routed job ticket
   --Modified On   :   08/02/2013 Sudalai Mani
   
   DECLARE @JOBSTARTED      DATETIME
    DECLARE @JOBCOMPLETED   DATETIME
    DECLARE @SITE         VARCHAR(50)
    DECLARE @PSITE         VARCHAR(50)
    DECLARE @JOB_NO         VARCHAR(50)
    DECLARE @JOB_SUB_NO      VARCHAR(3)
    DECLARE @STEP_NO      VARCHAR(20)
    DECLARE @STEP_NAME      VARCHAR(50)
    DECLARE @UNIT_COST      DECIMAL(18, 5)
    DECLARE @UNIT_COST_B   DECIMAL(18, 5)
    DECLARE @UNIT_COST_C   DECIMAL(18, 5)
    DECLARE @UNIT_COST_D   DECIMAL(18, 5)
    DECLARE @UNIT_COST_E   DECIMAL(18, 5)
    DECLARE @UNIT_COST_F   DECIMAL(18, 5)
    DECLARE @MARKUP         DECIMAL(18, 2)

   --Place holders for the current values for the work flow   
   DECLARE @ORG_SCHEDULED      DATETIME
   DECLARE @ORG_DEADLINE      DATETIME
   DECLARE @ORG_STARTED      DATETIME
   DECLARE @ORG_COMPLETED      DATETIME
   DECLARE @ORG_COST_CODE      VARCHAR(50)
   DECLARE @ORG_RESOURCE      VARCHAR(50)
   DECLARE @ORG_START_METER   INT
   DECLARE @ORG_END_METER      INT
   DECLARE @ORG_WASTE_METER   INT
   DECLARE @ORG_PERSONNEL      VARCHAR(50)
   DECLARE @ORG_LEVELGUID      VARCHAR(50)
   DECLARE @ORG_HOURS         DECIMAL(18, 2)
   DECLARE @ORG_QUANTITY      DECIMAL(18, 2)
   DECLARE @ORG_SLIDE01      DECIMAL(18, 2)
   DECLARE @ORG_SLIDE02      DECIMAL(18, 2)
   DECLARE @ORG_SLIDE03      DECIMAL(18, 2)
   DECLARE @ORG_SIDES         SMALLINT
   DECLARE @ORG_PAPER_TYPE      VARCHAR(50)
   DECLARE @ORG_VALUE01      VARCHAR(50)
   DECLARE @ORG_VALUE02      VARCHAR(50)
   DECLARE @ORG_VALUE03      VARCHAR(50)
   DECLARE @ORG_COMMENTS      VARCHAR(2048)
   DECLARE @CUSTOM01         VARCHAR(50)
   DECLARE @CUSTOM02         VARCHAR(50)
   DECLARE @CUSTOM03         VARCHAR(50)
   
    --Get the job work flow information
    SELECT
      @SITE             = [SITE]
      ,@JOB_NO          = [JOB_NO]
      ,@JOB_SUB_NO      = [JOB_SUB_NO]
      ,@STEP_NO         = [STEP_NO]
      ,@STEP_NAME       = [STEP_NAME]
      ,@ORG_SCHEDULED   = [SCHEDULED]
      ,@ORG_DEADLINE    = [DEADLINE]
      ,@ORG_STARTED     = [STARTED]
      ,@ORG_COMPLETED   = [COMPLETED] 
      ,@ORG_COST_CODE   = [COST_CODE]
      ,@ORG_RESOURCE    = [RESOURCE] 
      ,@ORG_START_METER = [START_METER]
      ,@ORG_END_METER   = [END_METER]
      ,@ORG_WASTE_METER = [WASTE_METER]
      ,@ORG_PERSONNEL   = [PERSONNEL]
      ,@ORG_LEVELGUID   = [LEVELGUID]
      ,@ORG_HOURS       = [HOURS]
      ,@ORG_QUANTITY    = [QUANTITY] 
      ,@ORG_SLIDE01     = [SLIDE01]
      ,@ORG_SLIDE02     = [SLIDE02]
      ,@ORG_SLIDE03     = [SLIDE03]
      ,@ORG_SIDES       = [SIDES]
      ,@ORG_VALUE01     = [VALUE01]
      ,@ORG_VALUE02     = [VALUE02]
      ,@ORG_VALUE03     = [VALUE03]
      ,@ORG_COMMENTS    = [COMMENTS]
    FROM   JOB_TICKET_WORKFLOW WITH(NOLOCK) 
    WHERE   ID = @ID
   
   --Get the parent site
   SELECT @PSITE = PARENT_SITE FROM VWJOBTICKETS WITH(NOLOCK) WHERE [SITE] = @SITE AND [JOB_NO] = @JOB_NO
   
    --Get the job task information
   SELECT   @CUSTOM01 = [CUSTOM01], @CUSTOM02 = [CUSTOM02], @CUSTOM03 = [CUSTOM03]
    FROM   JOB_TICKET_TASKS WITH(NOLOCK) 
    WHERE   ([SITE] = @SITE OR [SITE] = @PSITE) AND [JOB_NO] = @JOB_NO AND [STEP_NO] = @STEP_NO

    --Get the original start and completed dates
    SELECT   @JOBSTARTED = [STARTED], @JOBCOMPLETED = [COMPLETED]
    FROM   JOB_TICKET_ROUTES WITH(NOLOCK) 
    WHERE   [SITE] = @SITE AND JOB_NO = @JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO

   IF DATALENGTH(@PERSONNEL) > 0 
    BEGIN
        IF DATALENGTH(RTRIM(@LEVELGUID)) = 0
         SET @LEVELGUID = dbo.fn_GetStaffRoleGuid(@PERSONNEL, @SITE)
    END
   ELSE 
      SET @LEVELGUID = ''        

   BEGIN TRAN UPDATE_WF
      IF @COST_CODE <> (SELECT COST_CODE FROM JOB_TICKET_WORKFLOW WITH(NOLOCK) WHERE ID = @ID)
      BEGIN
         --Get the Unit Costs for this cost code
         SELECT   @UNIT_COST      = ISNULL(UNIT_COST, 0),
               @UNIT_COST_B   = ISNULL(UNIT_COST_B, 0),
               @UNIT_COST_C   = ISNULL(UNIT_COST_C, 0),
               @UNIT_COST_D   = ISNULL(UNIT_COST_D, 0),
               @UNIT_COST_E   = ISNULL(UNIT_COST_E, 0),
               @UNIT_COST_F   = ISNULL(UNIT_COST_F, 0),
               @MARKUP         = ISNULL(MARKUP, 0)
         FROM   COST_CODES WITH(NOLOCK) 
         WHERE   [SITE] = @SITE AND [COST_CODE] = @COST_CODE
         
         --Add to the work flow table
         UPDATE   JOB_TICKET_WORKFLOW 
         SET      SCHEDULED = @SCHEDULED
               ,[DEADLINE] = @DEADLINE
               ,[STARTED] = @STARTED
               ,COMPLETED = @COMPLETED
               ,COST_CODE = @COST_CODE
               ,UNIT_COST = @UNIT_COST
               ,UNIT_COST_B = @UNIT_COST_B
               ,UNIT_COST_C = @UNIT_COST_C
               ,UNIT_COST_D = @UNIT_COST_D
               ,UNIT_COST_E = @UNIT_COST_E
               ,UNIT_COST_F = @UNIT_COST_F
               ,MARKUP= @MARKUP
               ,[RESOURCE] = @RESOURCE
               ,START_METER = @START_METER
               ,END_METER = @END_METER
               ,WASTE_METER = @WASTE_METER
               ,PERSONNEL = @PERSONNEL
               ,[HOURS] = @HOURS
               ,PASSED = @QA
               ,QUANTITY = @QUANTITY
               ,COMMENTS = @COMMENTS
               ,UPDATED_BY = @USER
               ,UPDATED = GETDATE()
               ,LEVELGUID = @LEVELGUID
               ,VALUE01 = @VALUE01
               ,VALUE02 = @VALUE02
               ,VALUE03 = @VALUE03
               ,SIDES = @SIDES
         WHERE   ID = @ID
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END
      ELSE
      BEGIN
         --Add to the work flow table
         UPDATE   JOB_TICKET_WORKFLOW 
         SET      SCHEDULED = @SCHEDULED
               ,[DEADLINE] = @DEADLINE
               ,[STARTED] = @STARTED
               ,COMPLETED = @COMPLETED
               ,COST_CODE = @COST_CODE
               ,[RESOURCE] = @RESOURCE
               ,START_METER = @START_METER
               ,END_METER = @END_METER
               ,WASTE_METER = @WASTE_METER
               ,PERSONNEL = @PERSONNEL
               ,[HOURS] = @HOURS
               ,PASSED = @QA
               ,QUANTITY = @QUANTITY
               ,COMMENTS = @COMMENTS
               ,UPDATED_BY = @USER
               ,UPDATED = GETDATE()
               ,LEVELGUID = @LEVELGUID
               ,VALUE01 = @VALUE01
               ,VALUE02 = @VALUE02
               ,VALUE03 = @VALUE03
               ,SIDES = @SIDES
         WHERE   ID = @ID
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END
    
      --Update the status of the job if needed?
      IF @JOBSTARTED IS NULL AND @JOBCOMPLETED IS NULL
      BEGIN
         IF NOT @STARTED IS NULL
            UPDATE JOB_TICKET_ROUTES SET [started] = @started, updated = GETDATE(), updated_by = @user, 
            [resource] = @resource, personnel = @personnel WHERE [SITE] = @site AND JOB_NO = @JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO
         ELSE
            UPDATE JOB_TICKET_ROUTES SET [started] = GETDATE(), updated = GETDATE(), updated_by = @user, 
            [resource] = @resource, personnel = @personnel WHERE [SITE] = @site AND JOB_NO = @JOB_NO AND JOB_SUB_NO = @JOB_SUB_NO
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END
   
      --Record columns that where changed in the job ticket audit table
      --Schedule changed
      IF @ORG_SCHEDULED <> @SCHEDULED
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') SCHEDULE CHANGED', 
         CONVERT(VARCHAR(255), ISNULL(@ORG_SCHEDULED, '')), CONVERT(VARCHAR(255), ISNULL(@SCHEDULED, '')), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END       
      END
      
      --Deadline changed
      IF @ORG_DEADLINE <> @DEADLINE
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') DEADLINE CHANGED', 
         CONVERT(VARCHAR(255), ISNULL(@ORG_DEADLINE, '')), CONVERT(VARCHAR(255), ISNULL(@DEADLINE, '')), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END
   
      --Started changed
      IF @ORG_STARTED <> @STARTED
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') START DATE CHANGED', 
         CONVERT(VARCHAR(255), ISNULL(@ORG_STARTED, '')), CONVERT(VARCHAR(255), ISNULL(@STARTED, '')), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END
   
      --Complettion date changed
      IF @ORG_COMPLETED <> @COMPLETED 
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') COMPLETED DATE CHANGED', 
         CONVERT(VARCHAR(255), ISNULL(@ORG_COMPLETED, '')), CONVERT(VARCHAR(255), ISNULL(@COMPLETED, '')), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END      
      END
   
      --Cost code changed
      IF @ORG_COST_CODE <> @COST_CODE
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') COST CODE CHANGED', 
         @ORG_COST_CODE, @COST_CODE, GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END   
      
      --Resource changed
      IF @ORG_RESOURCE <> @RESOURCE 
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') RESOURCE CHANGED', 
         dbo.fn_GetResource('{' + @ORG_RESOURCE + '}'), dbo.fn_GetResource('{' + @RESOURCE + '}'), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END      
      END
      
      --Staff member changed
      IF @ORG_PERSONNEL <> @PERSONNEL
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') STAFF MEMBER CHANGED', 
         dbo.fn_GetPersonnelName('{' + @ORG_PERSONNEL + '}'), dbo.fn_GetPersonnelName('{' + @PERSONNEL + '}'), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END
   
      --Staff role changed
      IF @ORG_LEVELGUID <> @LEVELGUID
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') STAFF ROLE CHANGED', 
         dbo.fn_GetPersonnelLevel('{' + @ORG_LEVELGUID + '}'), dbo.fn_GetPersonnelLevel('{' + @LEVELGUID  + '}'), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END   
      END
   
      --Start meter changed
      IF @ORG_START_METER <> @START_METER
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') START METER CHANGED', 
         CONVERT(VARCHAR(50), @ORG_START_METER), CONVERT(VARCHAR(50), @START_METER), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END      
      END
   
      --End meter changed
      IF @ORG_END_METER <> @END_METER
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') END METER CHANGED', 
         CONVERT(VARCHAR(50), @ORG_END_METER), CONVERT(VARCHAR(50), @END_METER), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END
   
      --Waste meter changed
      IF @ORG_WASTE_METER <> @WASTE_METER
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') WASTE METER CHANGED', 
         CONVERT(VARCHAR(50), @ORG_WASTE_METER), CONVERT(VARCHAR(50), @WASTE_METER), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END      
      END
   
      --Staff hours changed
      IF @ORG_HOURS <> @HOURS
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') HOURS CHANGED', 
         CONVERT(VARCHAR(50), @ORG_HOURS), CONVERT(VARCHAR(50), @HOURS), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END 
      END

      --Quantity changed
      IF @ORG_QUANTITY <> @QUANTITY 
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') QUANTITY CHANGED', 
         CONVERT(VARCHAR(50), @ORG_QUANTITY), CONVERT(VARCHAR(50), @QUANTITY), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END    
      END
   
      --Slide1 changed
      IF @ORG_SLIDE01 <> @SLIDE01
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') SLIDE #1 CHANGED', 
         CONVERT(VARCHAR(50), @ORG_SLIDE01), CONVERT(VARCHAR(50), @SLIDE01), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END    
      END

      --Slide2 changed
      IF @ORG_SLIDE02 <> @SLIDE02
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') SLIDE #2 CHANGED', 
         CONVERT(VARCHAR(50), @ORG_SLIDE02), CONVERT(VARCHAR(50), @SLIDE02), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END    
      END

      --Slide3 changed
      IF @ORG_SLIDE03 <> @SLIDE03
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') SLIDE #3 CHANGED', 
         CONVERT(VARCHAR(50), @ORG_SLIDE03), CONVERT(VARCHAR(50), @SLIDE03), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END

      --Sides changed
      IF @ORG_SIDES <> @SIDES
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') NUMBER SIDES CHANGED', 
         CONVERT(VARCHAR(50), @ORG_SIDES), CONVERT(VARCHAR(50), @SIDES), GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END
   
      --Custom value 1 changed
      IF @ORG_VALUE01 <> @VALUE01
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') ' + 
         @CUSTOM01 + ' CHANGED', @ORG_VALUE01, @VALUE01, GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END
   
      --Custom value 3 changed
      IF @ORG_VALUE02 <> @VALUE02
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') ' + 
         @CUSTOM02 + ' CHANGED', @ORG_VALUE02, @VALUE02, GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END
   
      --Custom value 3 changed
      IF @ORG_VALUE03 <> @VALUE03
      BEGIN
         INSERT INTO JOB_TICKET_AUDITS (JOB_NO, [DESCRIPTION], OLDVALUE, NEWVALUE, UPDATED, UPDATED_BY)
         VALUES (@JOB_NO, 'The value for STEP# ' + @STEP_NO + '(' + CONVERT(VARCHAR(50), @ID) + ') ' + 
         @CUSTOM03 + ' CHANGED' , @ORG_VALUE03, @VALUE03, GETDATE(), @USER)
         IF @@ERROR <> 0
         BEGIN 
            ROLLBACK TRAN UPDATE_WF
            RETURN 
         END     
      END

      --Log transaction
      INSERT INTO EVENTS ([SITE], [USER], URL, COMMENTS) VALUES (@site, @user, @url, 'THE JOB STEP ' + 
      @STEP_NO + ' ' + @STEP_NAME + ' HAS BEEN UPDATE ON JOB #' + @JOB_NO + '-' + @JOB_SUB_NO)
      IF @@ERROR <> 0
      BEGIN 
         ROLLBACK TRAN UPDATE_WF
         RETURN 
      END 

   COMMIT TRAN UPDATE_WF
END

GO
 

CREATE PROCEDURE UNI_INSERT_FEEDBACK_LEGEND  
	@LEGEND	VARCHAR(500),
	@EMAIL	VARCHAR(100),
	@PHONE	VARCHAR(100) 
AS 
BEGIN 
	--Created By:	S.Sudalai Mani
	--Created On:	2013-08-15
	--Description:	Insert / Update the feedback legend to server settings table
	
	--is legend data valid?
	IF DATALENGTH(LTRIM(@LEGEND)) > 0
	BEGIN --yes, then insert or update
		--is legend already available?
		IF EXISTS (SELECT VARVALUE FROM SERVER_SETTINGS WITH(NOLOCK) WHERE VARNAME = 'FEEDBACK_LEGEND')
			--yes, then update the legend
			UPDATE SERVER_SETTINGS SET VARVALUE = @LEGEND WHERE VARNAME = 'FEEDBACK_LEGEND'
		ELSE 
			--no, then insert the legend
			INSERT INTO SERVER_SETTINGS VALUES (NEWID(), 'FEEDBACK_LEGEND', @LEGEND) 
	END 
	--is phone data valid?
	IF DATALENGTH(LTRIM(@PHONE)) > 0
	BEGIN --yes, then insert or update
		--is phone already available?
		IF EXISTS (SELECT VARVALUE FROM SERVER_SETTINGS WITH(NOLOCK) WHERE VARNAME = 'SUPPORT_PHONE')
			--yes, then update the phone
			UPDATE SERVER_SETTINGS SET VARVALUE = @PHONE WHERE VARNAME = 'SUPPORT_PHONE'
		ELSE 
			--no, then insert the phone
			INSERT INTO SERVER_SETTINGS VALUES (NEWID(), 'SUPPORT_PHONE', @PHONE) 
	END 
	--is email data valid?
	IF DATALENGTH(LTRIM(@EMAIL)) > 0
	BEGIN --yes, then insert or update
		--is email already available?
		IF EXISTS (SELECT VARVALUE FROM SERVER_SETTINGS WITH(NOLOCK) WHERE VARNAME = 'SUPPORT_EMAIL')
			--yes, then update the email
			UPDATE SERVER_SETTINGS SET VARVALUE = @EMAIL WHERE VARNAME = 'SUPPORT_EMAIL'
		ELSE 
			--no, then insert the email
			INSERT INTO SERVER_SETTINGS VALUES (NEWID(), 'SUPPORT_EMAIL', @EMAIL) 
	END 
	
END 

GO 

 

/****** Object:  StoredProcedure [dbo].[UNI_INSERT_SITE_WARNING_MESSAGES]    Script Date: 08/19/2013 14:30:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UNI_INSERT_SITE_WARNING_MESSAGES]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UNI_INSERT_SITE_WARNING_MESSAGES]
GO

  

 
CREATE PROCEDURE [dbo].[UNI_INSERT_SITE_WARNING_MESSAGES]
AS
BEGIN
	DECLARE @SITE VARCHAR(10)

	DECLARE WARNING_MESSAGE_CURSOR CURSOR FOR
 
	SELECT DISTINCT [SITE] FROM SITES WITH(NOLOCK) WHERE [ENABLED] = 1
 
	OPEN WARNING_MESSAGE_CURSOR
		FETCH NEXT FROM WARNING_MESSAGE_CURSOR INTO @SITE
			WHILE @@FETCH_STATUS = 0
			BEGIN
				
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'BILLWRN')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'BILLWRN','Invoiced job warning only','Warning, This job has already been billed and should not be altered!')
				END
				
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'BILLERR')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES
					(@SITE,'BILLERR','Invoiced job warning no changes allowed','This job has already been billed and cannot be altered!')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'ROUTELMT')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'ROUTELMT','Route limitation warning', [dbo].[fn_GetSystemVariable] (@SITE, 'ROUTE_LIMITED_MESSAGE'))
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'ONJOBMSG')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'ONJOBMSG','Currently on another job warning', 'You are currently working on another job. You must close out the previous job!')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '0')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'0','OK','OK')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '1000')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'1000','P&L number required','P&L number required')
				END
				
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '1001')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'1001','Invalid P&L number provided','Invalid P&L number provided')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '2000')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'2000','Core number required on an IBD Job','Core number required on an IBD Job')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '2001')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'2001','Sub core number required on an IBD Job','Sub core number required on an IBD Job')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '2002')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'2002','Invalid core number provided','Invalid core number provided')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '2003')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'2003','Invalid sub core number provided','Invalid sub core number provided')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '100')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'100','Invalid client number provided','Invalid client number provided')
				END
 				
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '101')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'101','Invalid matter number provided','Invalid matter number provided')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '3000')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'3000','Delivery checkbox must be checked','Delivery checkbox must be checked')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '102')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'102','The UserID does not match the Requestor','The UserID does not match the Requestor')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '200')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'200','Invalid deal code','Invalid deal code')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '300')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'300','Invalid Client/Project Code','Invalid Client/Project Code')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '301')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'301','Invalid Department','Invalid Department')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '2009')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'2009','A selection from the client agreement list is required!','A selection from the client agreement list is required!')
				END				

				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = '4000')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'4000','Non-IBD jobs cannot be accepted','Non-IBD jobs cannot be accepted')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'JBRBTWRN')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE,'JBRBTWRN','Routing of jobs with open task','A job cannot be re-routed until you close out all tasks that are currently flagged as started')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'ESTTMELMT')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE, 'ESTTMELMT', 'Estimation vs Completion threshold','The account of time spent on the job has exceeded the estimated duration')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'STAFFLOGIN')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE, 'STAFFLOGIN', 'Staff ID no mapped to login account','Your login account has not been associated to a staff id, Please contact your site adminstrator')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'SP00001')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE, 'SP00001', 'Site parameter missing','Site is required!')
				END
 
				IF NOT EXISTS(SELECT [CODE] FROM SITE_WARNING_MESSAGES WITH(NOLOCK) WHERE [SITE] = @SITE AND [CODE] = 'SP00002')
				BEGIN
					INSERT INTO SITE_WARNING_MESSAGES ([SITE], [CODE], [DESCRIPTION], [MESSAGE]) VALUES 
					(@SITE, 'SP00002', 'Job Number parameter missing','Job number is required!')
				END
 
			FETCH NEXT FROM WARNING_MESSAGE_CURSOR INTO @SITE
			END
		CLOSE WARNING_MESSAGE_CURSOR
	DEALLOCATE WARNING_MESSAGE_CURSOR
	
END
GO

/****** Object:  UserDefinedFunction [dbo].[fn_GetServerVariable]    Script Date: 08/19/2013 14:32:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_GetServerVariable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn_GetServerVariable]
GO



CREATE FUNCTION [dbo].[fn_GetServerVariable](@NAME NVARCHAR(50))
RETURNS NVARCHAR(200)
AS
BEGIN
	DECLARE @VALUE NVARCHAR(255)	
	SET @VALUE = ISNULL((SELECT VARVALUE FROM SERVER_SETTINGS WITH (NOLOCK) WHERE [VARNAME]=@NAME),'')
	RETURN @VALUE
END


GO

/****** Object:  StoredProcedure [dbo].[UNI_GET_NOTIFICATION_MESSAGE]    Script Date: 08/19/2013 14:45:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UNI_GET_NOTIFICATION_MESSAGE]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UNI_GET_NOTIFICATION_MESSAGE]
GO



CREATE PROCEDURE [dbo].[UNI_GET_NOTIFICATION_MESSAGE] (@TRAN_ROW NVARCHAR(50), @TRAN_TYPE NVARCHAR(50), @FEEDBACK_URL NVARCHAR(512))
AS
BEGIN
	/*
		Name		:   UNI_GET_NOTIFICATION_MESSAGE
		Description	:   Returns for message to is to be sent on and the destination email address based on the type of transaction
		Written On	:	02/17/2009 By Ruben Figueroa
		Updated On	:	07/15/2013 By Sudalai Mani
		Description	:	Include the feedback legend(if configured) into feedback message
	*/   
    
    DECLARE @SITE				NVARCHAR(20)
    DECLARE @JOB_TYPE			NVARCHAR(20)
    DECLARE @JOB_NO				NVARCHAR(20)   
	DECLARE @JOB_SUB_NO			NVARCHAR(3)
    DECLARE @PERSONNEL			NVARCHAR(50)
    DECLARE @PNL_EMAIL			NVARCHAR(255)
    DECLARE @NOTIFYGUID			UNIQUEIDENTIFIER
    DECLARE @COLUMN				NVARCHAR(255)
    DECLARE @TYPE				NVARCHAR(255)
    DECLARE @QUERY				NVARCHAR(MAX)
    DECLARE @SERVER				NVARCHAR(255)
    DECLARE @FROM				NVARCHAR(255)
    DECLARE @SUBJECT			NVARCHAR(255)
    DECLARE @MESSAGE			NVARCHAR(MAX)
    DECLARE @SIGNATURE			NVARCHAR(MAX)
    DECLARE @VALUE				NVARCHAR(255)
    DECLARE @MSGID				NVARCHAR(50)
    DECLARE @FEEDBACK_MSG		NVARCHAR(500)
    DECLARE @FEEDBACK_LEGEND	NVARCHAR(500)
	DECLARE @CLIENT_TIMEZONE	NVARCHAR(255)
    DECLARE @SERVER_TIMEZONE	NVARCHAR(255)
    DECLARE @ISADMIN			BIT
    DECLARE @FB					INT

    SET NOCOUNT ON
    SET @SERVER_TIMEZONE = [dbo].[fn_GetServerTimeZone]()

    DECLARE @STE DATETIME
    SELECT @STE = GETDATE()

    --Get site and job type 
	SELECT	@SITE = [SITE], @JOB_TYPE = JOB_TYPE, @JOB_NO = JOB_NO, @JOB_SUB_NO = JOB_SUB_NO, 
			@ISADMIN = (CASE WHEN NON_PRODUCTION = 3 THEN 1 ELSE 0 END), @MSGID = MSGID, @PERSONNEL = PERSONNEL
	FROM	VWJOBTICKETS WITH(NOLOCK)
    WHERE	ROUTEGUID = @TRAN_ROW

	--Check for feedback
    SET @FB = (SELECT COUNT(F.RGUID) FROM site_job_feedback f WITH(NOLOCK) JOIN site_job_types t WITH(NOLOCK) ON t.rguid = f.jobtypeguid
				WHERE t.[site] = @SITE AND t.job_type = @JOB_TYPE)

	--Do we have feedback questions? 
    IF @FB > 0
    BEGIN
		--Do we need to include a feedback url
        SET @FEEDBACK_MSG = ''
        SET @FEEDBACK_LEGEND = ''
        
        IF (dbo.fn_GetSystemVariable (@SITE, 'INCLUDE_FEEDBACK_LINK')) = 'ON'
        BEGIN
            SET @FEEDBACK_MSG = dbo.fn_GetSystemVariable (@SITE,'FEEDBACK_LINK_MESSAGE')
            SET @FEEDBACK_URL = '<' + @FEEDBACK_URL + '?ID=' + REPLACE(REPLACE(@TRAN_ROW, '}',''),'{','') + '>'
            SET @FEEDBACK_LEGEND = dbo.fn_GetServerVariable ('FEEDBACK_LEGEND')
            IF DATALENGTH(RTRIM(@FEEDBACK_LEGEND)) > 0 
				SET @FEEDBACK_MSG = @FEEDBACK_MSG + ' Please rate our service (' + @FEEDBACK_LEGEND + ').'
        END
        ELSE
            SET @FEEDBACK_URL = ''
    END
    ELSE
        SET @FEEDBACK_URL = ''

	--Get the default subject and message body
    SELECT	@SERVER				=	MAIL_SERVER, 
			@FROM				=	(CASE WHEN DATALENGTH(RTRIM(MAIL_FROM)) > 0 THEN MAIL_FROM ELSE 'SYMPHONY@WILLIAMSLEA.COM' END), 
			@SUBJECT			=	(CASE WHEN DATALENGTH(RTRIM(DEFAULT_SUBJECT)) > 0 THEN DEFAULT_SUBJECT ELSE 'SYMPHONY JOB REQUEST NOTICE' END), 
			@MESSAGE			=	(CASE WHEN DATALENGTH(RTRIM(DEFAULT_MESSAGE)) > 0 THEN DEFAULT_MESSAGE  ELSE '' END) + CHAR(13) + CHAR(10) ,
			@SIGNATURE			=	(CASE WHEN DATALENGTH(RTRIM(DEFAULT_SIGNATURE)) > 0 THEN DEFAULT_SIGNATURE  ELSE '' END),
			@CLIENT_TIMEZONE	=	UPPER((CASE WHEN DATALENGTH(RTRIM(ISNULL(TIMEZONEID, ''))) > 0 THEN TIMEZONEID ELSE @SERVER_TIMEZONE END))
    FROM	SITES WITH(NOLOCK)
    WHERE	[SITE] = @SITE
   
    --Get the custom notification information for this type of request  
    SELECT	@NOTIFYGUID	=	RGUID,
			@SUBJECT	=	(CASE WHEN DATALENGTH(RTRIM([SUBJECT])) > 0 THEN [SUBJECT] ELSE @SUBJECT END),
			@MESSAGE	=	(CASE WHEN DATALENGTH(RTRIM([MESSAGE_BODY])) > 0 THEN [MESSAGE_BODY] ELSE @MESSAGE END)
    FROM	NOTIFICATIONS WITH(NOLOCK) 
    WHERE	[SITE] = @SITE AND JOB_TYPE = @JOB_TYPE AND METHOD = @TRAN_TYPE

	--Do we have a message id
    IF DATALENGTH(RTRIM(@MSGID)) > 0 
    BEGIN
		SELECT	@NOTIFYGUID	=	RGUID,
				@SUBJECT	=	(CASE WHEN DATALENGTH(RTRIM([SUBJECT])) > 0 THEN [SUBJECT] ELSE @SUBJECT END),  
				@MESSAGE	=	(CASE WHEN DATALENGTH(RTRIM([MESSAGE_BODY])) > 0 THEN [MESSAGE_BODY] ELSE @MESSAGE END)
        FROM	NOTIFICATIONS WITH(NOLOCK) 
        WHERE	[SITE] = @SITE AND JOB_TYPE = @JOB_TYPE AND METHOD = @TRAN_TYPE AND MSGID = @MSGID
    END

    --Build the list of destination email addresses
    CREATE TABLE #EMAIL_ADDRESSES
    (
		[DESTINATION] NVARCHAR(255)
    )

    --Get get the regular email addresses
	INSERT INTO #EMAIL_ADDRESSES
    SELECT	DESTINATION 
    FROM	NOTIFICATION_DESTINATIONS WITH(NOLOCK) 
    WHERE	NOTIFYGUID = @NOTIFYGUID AND EMAIL_SOURCE = 'E'

    --Is this an intake notification
    --IF @TRAN_TYPE='INTAKE' AND DATALENGTH(@PERSONNEL)>0
    --BEGIN
    --    SET @PNL_EMAIL = ISNULL((SELECT EMAIL FROM USERS WITH (NOLOCK) WHERE STAFF_ID=@PERSONNEL),'')
    --    IF DATALENGTH(@PNL_EMAIL)>0
    --    BEGIN
    --       INSERT INTO #EMAIL_ADDRESSES (DESTINATION) VALUES (@PNL_EMAIL)
    --    END
    --END

	--Now, find the email addresses based on the columns on the job ticket we were told to look at
    SET @QUERY = 'TRUNCATE TABLE #EMAIL_FIELD_VALUES' + CHAR(13) + CHAR(10)
    
    DECLARE EMAIL_CURSOR CURSOR FAST_FORWARD FOR
		SELECT	DESTINATION 
		FROM	NOTIFICATION_DESTINATIONS WITH(NOLOCK) 
		WHERE	NOTIFYGUID = @NOTIFYGUID AND EMAIL_SOURCE = 'J'    

	OPEN EMAIL_CURSOR
		FETCH NEXT FROM EMAIL_CURSOR INTO @COLUMN
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF DATALENGTH(RTRIM(@COLUMN)) > 0 
			BEGIN
				SET @QUERY = @QUERY + 'INSERT INTO #EMAIL_ADDRESSES ([DESTINATION]) ' + CHAR(13) + CHAR(10)
				SET @QUERY = @QUERY + ' SELECT [' + @COLUMN + '] FROM VWJOBTICKETS WITH(NOLOCK) '
				SET @QUERY = @QUERY + ' WHERE JOB_NO = ''' + @JOB_NO + ''' AND JOB_SUB_NO = ''' + @JOB_SUB_NO + 
							''' AND DATALENGTH(RTRIM([' + @COLUMN + '])) > 0' + CHAR(13) + CHAR(10)
			END
			FETCH NEXT FROM EMAIL_CURSOR INTO @COLUMN
		END
		
    CLOSE EMAIL_CURSOR
    DEALLOCATE EMAIL_CURSOR

    --Build the list of destination email addresses
    CREATE TABLE #EMAIL_FIELD_VALUES
    (
        [COLUMN] NVARCHAR(1024),
        [VALUE]  NVARCHAR(4000),
        [TYPE]   NVARCHAR(1024)
    )

	DECLARE COLUMN_CURSOR CURSOR FAST_FORWARD FOR
		SELECT	DISTINCT FIELD = RTRIM(c.name), [TYPE] = t.name
		FROM	sys.objects o WITH(NOLOCK) JOIN sys.columns c WITH(NOLOCK) ON o.object_id = c.object_id 
				JOIN sys.types t WITH(NOLOCK) ON c.user_type_id = t.user_type_id
		WHERE	o.name IN ('JOB_TICKETS', 'JOB_TICKET_JTINFO') AND o.[type] = 'U' AND NOT c.name IN ('ID', 'RGUID', 'JOB_SUB_NO')
		ORDER BY FIELD

		OPEN COLUMN_CURSOR
        FETCH NEXT FROM COLUMN_CURSOR INTO @COLUMN, @TYPE
			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF DATALENGTH(RTRIM(@COLUMN)) > 0 AND CHARINDEX('[@' + @COLUMN + '@]', @MESSAGE) > 0
				BEGIN
					IF @COLUMN = 'JOB_NO'
					BEGIN
						SET @QUERY = @QUERY + 'INSERT INTO #EMAIL_FIELD_VALUES ([COLUMN], [VALUE]) ' + CHAR(13) + CHAR(10) 
						SET @QUERY = @QUERY + ' SELECT ''[@JOB_SUB_NO@]'', [JOB_SUB_NO] FROM VWJOBTICKETS WITH(NOLOCK) '
						SET @QUERY = @QUERY + ' WHERE JOB_NO = ''' + @JOB_NO + ''' AND JOB_SUB_NO = ''' + @JOB_SUB_NO + '''' + CHAR(13) + CHAR(10)
					END

					SET @QUERY = @QUERY + 'INSERT INTO #EMAIL_FIELD_VALUES ([COLUMN], [VALUE]) ' + CHAR(13) + CHAR(10)
					IF UPPER(@TYPE) = 'DATETIME' 
						SET @QUERY = @QUERY + ' SELECT ''[@' + @COLUMN + '@]'', ISNULL(dbo.fn_GetDateTimeByTZName(['+ @COLUMN + '], ''' + 
						@SERVER_TIMEZONE + ''', ''' + @CLIENT_TIMEZONE + '''), '''') FROM VWJOBTICKETS WITH(NOLOCK) '
					ELSE
						SET @QUERY = @QUERY + ' SELECT ''[@' + @COLUMN + '@]'', ['+ @COLUMN + '] FROM VWJOBTICKETS WITH(NOLOCK) '
					SET @QUERY = @QUERY + ' WHERE JOB_NO = ''' + @JOB_NO + ''' AND JOB_SUB_NO = ''' + @JOB_SUB_NO + '''' + CHAR(13) + CHAR(10)
				END
				FETCH NEXT FROM COLUMN_CURSOR INTO @COLUMN, @TYPE
			END
        
		CLOSE COLUMN_CURSOR
        DEALLOCATE COLUMN_CURSOR

	IF DATALENGTH(RTRIM(@QUERY)) > 0 
    BEGIN
        --Build the column list with values
        EXEC UNI_EXECUTESQL @QUERY                             

        --Put the columns and values in a cursor
        DECLARE COLUMN_CURSOR CURSOR FAST_FORWARD FOR
			SELECT [COLUMN], [VALUE] FROM #EMAIL_FIELD_VALUES WITH(NOLOCK)
        
        OPEN COLUMN_CURSOR
			--Loop thru each column for this type of job
			FETCH NEXT FROM COLUMN_CURSOR INTO @COLUMN, @VALUE
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--Replace the column with the data on the ticket
				IF CHARINDEX(@COLUMN, @MESSAGE) > 0            
					SET @MESSAGE = REPLACE(@MESSAGE, @COLUMN, @VALUE)
            
				IF CHARINDEX(@COLUMN, @SUBJECT) > 0
					SET @SUBJECT = REPLACE(@SUBJECT, @COLUMN, @VALUE)
            
				FETCH NEXT FROM COLUMN_CURSOR INTO @COLUMN, @VALUE
			END

		--Clean up
        CLOSE COLUMN_CURSOR
        DEALLOCATE COLUMN_CURSOR
        
    END       

	--Send, only if not an admin job
	IF @ISADMIN = 0
		SELECT	MAIL_SERVER = RTRIM(@SERVER), MAIL_FROM = RTRIM(@FROM), [SUBJECT] = RTRIM(@SUBJECT) , 
				[MESSAGE] = RTRIM(@MESSAGE), [DESTINATION], FEEDBACK_MESSAGE = RTRIM(@FEEDBACK_MSG), 
				FEEDBACK_URL = RTRIM(@FEEDBACK_URL), [SIGNATURE] = RTRIM(@SIGNATURE), [JOB_NO] = @JOB_NO + '-' + @JOB_SUB_NO
        FROM #EMAIL_ADDRESSES WITH (NOLOCK)

    DROP TABLE #EMAIL_FIELD_VALUES
    DROP TABLE #EMAIL_ADDRESSES

END



GO

ALTER PROCEDURE [dbo].[UNI_GET_JSD_INFO_BY_STAFFID]
	@SITE		NVARCHAR(10),
	@ROLE		NVARCHAR(50),
	@PRODTYPE	SMALLINT = -1,
	@STAFFID	NVARCHAR(50)
AS 
BEGIN 
	/* 
		Name	    :	UNI_GET_JSD_INFO_BY_STAFFID
		Description :   Returns the job status information request results by StaffID 
		Written On  :   03/04/2011 M. de Melo Jr. 
		Updated On  :   03/2/2011 Ruben Figueroa 
		Description :   Set distinct based on job record, 
				added j.personnel filter condition commmented out the @PRODTYPE check,
				prodution type not required on my jobs layer 
		Updated On  :   03/23/2011 Ruben Figueroa 
		Description :   Enhanced to support production type flag 
		Updated On  :   08/03/2011 Monish Jain 
		Description :   Optimized performance. 
	*/ 
	--Do we have a site
	IF DATALENGTH(RTRIM(@SITE)) = 0 
	
	BEGIN 
		
		RAISERROR ('SITE IS REQUIRED', 10, 1) 
		
		RETURN 
	
	END 
	
	--Do we have a role 
	
	IF DATALENGTH(RTRIM(@ROLE)) = 0 
	
	BEGIN 
		
		RAISERROR ('ROLE IS REQUIRED', 10, 1) 
		
		RETURN 
	
	END 
	
	----Do we have a staffid
	
	--IF DATALENGTH(RTRIM(@STAFFID)) = 0 
	
	--BEGIN
	
		--RAISERROR ('STAFF ID IS REQUIRED', 16, 1)
	
		--RETURN
	
	--END
   
	
	
	--Is it a valid site
	
	IF NOT EXISTS(SELECT TOP 1 ID FROM SITES WITH(NOLOCK) WHERE [SITE] = @SITE)
	
	BEGIN
		
		RAISERROR ('INVALID SITE GIVEN', 10, 1)
		
		RETURN
	
	END

	
	
	--Is it a valid site
	
	IF NOT EXISTS(SELECT TOP 1 ID FROM ROLES WITH(NOLOCK) WHERE [SITE] = @SITE AND [ROLE] = @ROLE)
	
	BEGIN
		
		RAISERROR ('INVALID ROLE GIVEN', 10, 1)
		
		RETURN
	
	END 

	--Is it a valid 
	
	DECLARE @MAXROWS VARCHAR(4)
	
	SELECT @MAXROWS = ISNULL(varvalue, '50') FROM SETTINGS WITH(NOLOCK) WHERE [SITE] = @SITE AND varname = 'JSD_LIMIT'

	--Do we have settings for the role provided
	
	IF NOT EXISTS(SELECT TOP 1 ID FROM SITE_JSD_FIELDS WITH(NOLOCK) WHERE [SITE] = @SITE AND [ROLE] = @ROLE)
		
		EXEC UNI_GET_JSD_LAYOUT @SITE, @ROLE

	

	DECLARE @QUERY VARCHAR(MAX)

	--Build cursor that will build the default field list for the job status display
	
	SET @QUERY = '' 

	SELECT	@QUERY = @QUERY + 
		CASE WHEN Tbl = 'CALC' THEN 
		CASE WHEN FIELD = 'TIMELEFT' THEN ',TIMELEFT=dbo.fn_DiffDHMStr(GETDATE(),DUE_DATE)' 
		WHEN FIELD = 'ESTLEFT'  THEN ',ESTLEFT=dbo.fn_DiffDHMStr(GETDATE(),dateadd(n,dbo.fn_CalculateSLA(J.[SITE],J.JOB_NO,J.JOB_SUB_NO,NO_SETS,NO_ORIGINALS), requested_date))'
				
		WHEN FIELD = 'PRJLEFT'  THEN ',PRJLEFT=dbo.fn_DiffDHMStr(GETDATE(),dateadd(n,dbo.fn_ClientSLA(J.[SITE],JOB_TYPE,NO_SETS,NO_ORIGINALS,RUSH), requested_date))'
				
		WHEN FIELD = 'DISPLAY_CODE' THEN ', [DISPLAY_CODE]=(CASE WHEN ISNULL(DISPLAY_CODE,'''') ='''' THEN JOB_TYPE ELSE DISPLAY_CODE END) '
				
		WHEN FIELD = 'READYBY' THEN ',[READYBY]=dateadd(n,dbo.fn_CalculateSLA(J.[SITE],J.JOB_NO,J.JOB_SUB_NO,NO_SETS,NO_ORIGINALS), requested_date) '
				
		WHEN FIELD = 'ESTIMATE' THEN ',[ESTIMATE]=dbo.fn_EstimateRuntime(J.[SITE],J.JOB_NO,J.JOB_SUB_NO,NO_SETS,NO_ORIGINALS) '
				
		WHEN FIELD = 'SLADATE' THEN ',[SLADATE]=dateadd(n,dbo.fn_ClientSLA(J.[SITE],JOB_TYPE,NO_SETS,NO_ORIGINALS,RUSH), requested_date) '
				
		ELSE ''
            END 
		WHEN FIELD='JOB_NO' THEN ',JOB_NO=J.JOB_NO + ''-'' + J.JOB_SUB_NO'
			
		WHEN UPPER(FIELD)='PERSONNEL' THEN ',PERSONNEL=dbo.fn_GetPersonnel(CASE WHEN J.PERSONNEL=''' +@STAFFID + ''' THEN J.PERSONNEL ELSE W.PERSONNEL END)'
			
		WHEN UPPER(FIELD)='RESOURCE'  THEN ',RESOURCE=dbo.fn_GetResource(J.RESOURCE)'
			
		WHEN UPPER(ST.Name) LIKE '%CHAR' THEN ',' + FIELD + '=ISNULL(J.' + FIELD + ','''')'
			
		WHEN UPPER(ST.Name) LIKE '%TEXT' THEN ',' + FIELD + '=ISNULL(J.' + FIELD + ','''')'
			
		WHEN UPPER(ST.Name) IN ('BIT','DECIMAL','INT','SMALLINT','TINYINT') THEN ',' + FIELD + '=ISNULL(J.' + FIELD + ',0)'
			
		WHEN FIELD='ROUTE_LIMITED' THEN ',[ROUTE_LIMITED]=CASE WHEN (ROUTE_LIMITED=1 THEN ''LIMITED'' ELSE '''' ' 
			
		ELSE ', J.' + FIELD +  CHAR(13) END 
	FROM	SITE_JSD_FIELDS J WITH(NOLOCK) LEFT JOIN SYS.OBJECTS SO WITH(NOLOCK) ON SO.Name = J.Tbl 
		LEFT JOIN SYS.COLUMNS SC WITH(NOLOCK) ON SO.Object_Id = SC.Object_Id AND SC.Name = J.Field 
		LEFT JOIN SYS.TYPES ST WITH(NOLOCK) ON SC.User_Type_Id = ST.User_Type_Id 
	WHERE	[SITE] = @SITE AND [ROLE] = @ROLE 
	ORDER BY Sorder

	DECLARE @SQL VARCHAR(MAX)
 	SET @SQL = 'SELECT  * '  + 
		 ',SFC=dbo.SFC([SITE],[REMAIN] * 60)' + 
		',SBC=dbo.SBC([SITE],[REMAIN] * 60)' + 
		 ',PFC=dbo.PFC([SITE],[SLAREM] * 60)' + 
		',PBC=dbo.PBC([SITE],[SLAREM] * 60)' + 
		',EFC=dbo.EFC([SITE],[PRCREM] * 60)' + 
		',EBC=dbo.EBC([SITE],[PRCREM] * 60)' + 
		',RFC=dbo.RFC([SITE])' + 
		',RBC=dbo.RBC([SITE])' + 
		',MFC=dbo.MFC([SITE])' +
		',MBC=dbo.MBC([SITE])' + 
		',PRFC=dbo.PRFC([SITE])' + 
		',PRBC=dbo.PRBC([SITE])' + 
            
		',VFC=dbo.VFC([SITE])' + 
            
		',VBC=dbo.VBC([SITE])' + 
		' FROM (' + 
          
		'SELECT TOP ' + @MAXROWS + ' * ' + 
            
		',REMAIN=datediff(n, getdate(), DUE_DATE)/60.0' + 
            
		',PRCREM=datediff(n,getdate(),isnull(READYBY,DUE_DATE))/60.0' + 
		',SLAREM=(case when TRACK_WORKFLOW=1 and not SLADATE is null then datediff(n,getdate(),isnull(SLADATE,DUE_DATE))/60.0 else datediff(n,getdate(),isnull(READYBY,DUE_DATE))/60.0 end)' + 
		' FROM ('+ 
		'SELECT DISTINCT ' + REPLACE (SUBSTRING(@QUERY,2, DATALENGTH(@QUERY)), '= ','=')  + 
		',SORDER = (CASE WHEN STATUS IN (''INTAKE'',''RESERVATION'') THEN 0 WHEN STATUS=''PENDING'' THEN 1 WHEN STATUS=''SCHEDULED'' THEN 2 WHEN STATUS=''PROCESSING'' THEN 3 ELSE 4 END)' +  
		' FROM vwJOBTICKETS  J WITH (NOLOCK)'  + 
		 ' JOIN JOB_TICKET_WORKFLOW W WITH (NOLOCK) ON W.SITE=J.SITE AND W.JOB_NO=J.JOB_NO AND W.JOB_SUB_NO=J.JOB_SUB_NO  '  + 
		' WHERE J.[SITE]=''' + @SITE  + '''' +  
		(CASE WHEN @PRODTYPE >=0 THEN ' AND NON_PRODUCTION=' + CONVERT(VARCHAR(3), @PRODTYPE) ELSE ' ' END) + 
		' AND J.COMPLETED IS NULL AND (J.PERSONNEL=''' + @STAFFID + ''' OR (W.COMPLETED IS NULL AND W.PERSONNEL = ''' + @STAFFID + '''))  
		 AND DATALENGTH(''' + @STAFFID + ''')>0 ' +  
		') P ORDER BY SORDER,DUE_DATE ) R;' 
	
	EXEC UNI_ExecuteSql  @SQL
	
	END 
GO 
		





ALTER PROCEDURE [dbo].[UNI_GET_JOB_UNUSED_FIELDS_FILTER] 
	@SITE		VARCHAR(20),
	@JOBTYPE	VARCHAR(20),
	@FIELD		VARCHAR(25),
	@DTYPE		VARCHAR(20)
AS 
BEGIN 
	--Name		:	UNI_GET_JOB_UNUSED_FIELDS_FILTER
	--Written By	:	m de Melo Jr
	--Written On	:	05/07/2008
	--Description	:	Gets job configuration based on the site and job code, field and dtype given

	--Do we have a site?
	IF DATALENGTH(RTRIM(@SITE)) = 0 
	BEGIN
		RAISERROR ('SITE IS REQUIRED!', 16, 1)
		RETURN
	END 

	--Do we have a project code?
	IF DATALENGTH(RTRIM(@JOBTYPE)) = 0 
	BEGIN
		RAISERROR ('JOB TYPE IS REQUIRED!', 16, 1)
		RETURN
	END

	--Do we have a project type?
	IF NOT EXISTS(SELECT ID FROM SITE_JOB_TYPES JT WITH(NOLOCK) WHERE JT.[SITE] = @SITE AND JT.JOB_TYPE = @JOBTYPE)
		RETURN


	--Get System Columns
	SELECT	* 
	FROM	(SELECT	DISTINCT [Column_name]	=	SUBSTRING(c.name, 1, 32), 
					[Column_type]			=	TYPE_NAME(c.xtype), 
					[Column_length]			=	CASE WHEN TYPE_NAME(c.xtype) = 'decimal' THEN c.[length] - 1 ELSE c.[length] END 
			FROM	sysobjects o JOIN syscolumns c ON c.id = o.id 
			WHERE	o.name IN ('job_tickets', 'job_ticket_jtinfo') 
			) fields 
	WHERE	[Column_name] NOT IN (SELECT JT.FIELD FROM SITE_JOB_HEADERS JT WITH(NOLOCK) 
			WHERE JT.[SITE] = @SITE AND JT.JOB_TYPE = @JOBTYPE) AND COLUMN_NAME LIKE + '%' + @FIELD + '%'
			AND COLUMN_TYPE LIKE + '%' + @DTYPE + '%' AND [Column_name] NOT IN ('ID', 'RGUID', 'SITE', 'PARENT_SITE', 'JOB_TYPE', 
			'INVOICE_NO', 'INVOICED', 'INVOICE_AMT', 'NQUEUE', 'NQ_METER_CNT', 'STATUS', 'LAST_STEP', 'COMPLETED', 'TRACK_WORKFLOW', 
			'UPDATED', 'JOB_SUB_NO', 'QUANTITY', 'SCHEDULED', 'PPM', 'CPP', 'PLU', 'SHIFT', 'RATE', 'CREATED', 'CREATED_BY', 'STARTED', 
			'RESOURCE', 'PERSONNEL', 'BATES_01', 'BATES_02', 'START_METER', 'END_METER', 'WASTE_METER', 'ORIG_JOB_NO', 'VENDED', 
			'VENDED_READY', 'VENDED_COST', 'SHIPPED', 'SHIP_VIA', 'SHIP_COST', 'BOSS', 'UPDATED_BY', 'SETUP_TIME', 'CLEANUP_TIME', 
			'REQUESTED_TIME', 'DUE_TIME', 'ORIG_DUE_DATE', 'ORIG_DUE_TIME', 'QA_BY', 'QA_DATE', 'QA_PASSED', 'BNQUEUE', 'OLIVER', 
			'NON_PRODUCTION', 'OWNER', 'ACCEPTED_BY', 'ACCEPTED_DATE', 'COMMENTS', 'CLOSED', 'ROUTED', 'REVISED', 'BILLED', 'BILLABLE', 
			'FINAL_STATUS', 'PRJGUID', 'ROUTE_LIMITED', 'MSGID', 'VENDED_TO', 'VENDOR_INVOICE_NO', 'NOT_BILLABLE') 

	END 


GO 

 CREATE PROCEDURE [dbo].[RPT_RBS_FEEDBACK]
	@SITES		NVARCHAR(1024),
	@JOBTYPE	NVARCHAR(20),
	@FROMDATE	DATETIME,
	@TODATE     DATETIME,
	@USER		NVARCHAR(50),
	@URL		NVARCHAR(255)
AS
BEGIN
	/*
		Name		:   RPT_RBS_FEEDBACK
		Written On	:   09/09/2013 by Sudalai Mani 
		Description	:   Produces the output for the Feedback Report
	*/

	--DO WE HAVE A SITE
	IF DATALENGTH(RTRIM(@SITES)) = 0 
	BEGIN
		RAISERROR ('SITE IS REQUIRED', 16, 1)
		RETURN
	END

	--DO WE HAVE A JOBTYPE
	IF DATALENGTH(RTRIM(@JOBTYPE)) = 0 
	BEGIN
		RAISERROR ('JOBTYPE IS REQUIRED', 16, 1)
		RETURN
	END

	--DO WE HAVE A START DATE
	IF @FROMDATE IS NULL
	BEGIN
		RAISERROR ('STARTING DATE IS REQUIRED', 16, 1)
		RETURN
	END

	--DO WE HAVE AN END DATE
	IF @TODATE IS NULL
	BEGIN
		RAISERROR ('ENDING DATE IS REQUIRED', 16, 1)
		RETURN
	END

	--Check ALL site option
	IF LTRIM(RTRIM(@SITES)) = 'ALL' 
	BEGIN 
		--Do we have user name
		IF DATALENGTH(RTRIM(@USER)) = 0
		BEGIN 
			RAISERROR ('USER NAME IS REQUIRED', 16, 1)
			RETURN
		END 
		--get comma separated site name		
		SELECT	@SITES = COALESCE(@SITES + ',', '') + US.[SITE] 
		FROM	USER_SITES US WITH(NOLOCK) JOIN SITES S WITH(NOLOCK) ON S.[SITE] = US.[SITE]   		
		WHERE	US.[USER] = @USER AND S.[ENABLED] = 1    
	END

	SET @SITES = REPLACE(@SITES, '''', '')

	-- Declare cursor needed to build results
	DECLARE FEEDBACK_RESULTS CURSOR LOCAL FAST_FORWARD FOR
		SELECT	j.job_no,
				j.[Site],
				[Requestor]			=	j.requested_by, 
				[QUALITY]			=	CASE WHEN QUESTION LIKE '%QUALITY%'	THEN ANSWER ELSE '' END, 
				[DEADLINE]		=	CASE WHEN QUESTION LIKE '%DEADLINE%' THEN ANSWER ELSE '' END, 				
				[CUSTOMER SERVICE]	=	CASE WHEN QUESTION LIKE '%CUSTOMER SERVICE%' THEN ANSWER ELSE '' END, 
				[COMMENTS]			=	LTRIM(CASE WHEN QUESTION LIKE '%COMMENTS%' THEN ANSWER ELSE ' ' END + COMMENTS)
		FROM	FEEDBACK_REQUESTS FS WITH(NOLOCK) INNER HASH JOIN FEEDBACK_RESULTS F WITH(NOLOCK) 
				ON f.fbguid = fs.fbguid 
				INNER HASH JOIN vwJOBTICKETS J WITH(NOLOCK) ON J.ROUTEGUID = F.jobguid
		WHERE	J.COMPLETED BETWEEN @FROMDATE AND @TODATE AND DBO.FN_INSTRING(J.[SITE], @SITES, ',') = 1
				AND J.JOB_TYPE LIKE @JOBTYPE AND j.[status] = 'COMPLETED'
		ORDER BY J.JOB_NO

	-- Declare table needed to build results
	CREATE TABLE #SQL 
	(
		[Site]				NVARCHAR(20),
		[Job No]			NVARCHAR(10),
		[Requestor]			NVARCHAR(100),
		[Quality]			INT, 
		[Deadline]			INT, 
		[Customer Service]	INT, 
		[Comments]			VARCHAR(2048)
	)

	-- Declare variables for cursor
	DECLARE	@TJOB_NO			NVARCHAR(10)
	DECLARE @SITE				NVARCHAR(20)
	DECLARE	@Requestor			NVARCHAR(100)
	DECLARE	@QUALITY			INT 
	DECLARE	@DEADLINE			INT 
	DECLARE	@CUSTOMERSERVICE	INT 
	DECLARE	@COMMENTS			VARCHAR(2048)

	-- Open and fetch row
	OPEN FEEDBACK_RESULTS
		FETCH NEXT FROM FEEDBACK_RESULTS INTO @TJOB_NO, @SITE, @REQUESTOR, @QUALITY, @DEADLINE, @CUSTOMERSERVICE, @COMMENTS
		WHILE @@FETCH_STATUS = 0
		BEGIN 
			IF NOT EXISTS (SELECT [JOB NO] FROM #SQL WHERE [JOB NO] = @TJOB_NO)
			BEGIN
				INSERT INTO #SQL ([Job No], [Site], [Requestor], [QUALITY], [DEADLINE], [CUSTOMER SERVICE], [COMMENTS])
				VALUES (@TJOB_NO, @SITE, @REQUESTOR, @QUALITY, @DEADLINE, @CUSTOMERSERVICE, @COMMENTS)
			END 
			ELSE
			BEGIN
				UPDATE	A 
				SET		[QUALITY]			=	[QUALITY] + ISNULL(@QUALITY, 0),
						[DEADLINE]			=	[DEADLINE] + ISNULL(@DEADLINE, 0),
						[CUSTOMER SERVICE]	=	[CUSTOMER SERVICE]+ ISNULL(@CUSTOMERSERVICE, 0),
						[COMMENTS]			=	[COMMENTS] + ISNULL(@COMMENTS, '')
				FROM	#SQL A
				WHERE	[Job No] = @TJOB_NO
			END		
			FETCH NEXT FROM FEEDBACK_RESULTS INTO @TJOB_NO, @SITE, @REQUESTOR, @QUALITY, @DEADLINE, @CUSTOMERSERVICE, @COMMENTS
		END

	-- Clean up
	CLOSE FEEDBACK_RESULTS
	DEALLOCATE FEEDBACK_RESULTS

	-- Select columns from table and clean up
	SELECT * FROM #SQL ORDER BY [JOB NO]

	DROP TABLE #SQL

END

GO

CREATE PROCEDURE [dbo].[RPT_MACQUARIE_PRODUCTION_OVERVIEW]
	@SITES		VARCHAR(1024),
	@TYPE		VARCHAR(20),
	@FROMDATE	DATETIME,
	@TODATE		DATETIME,
	@USER		VARCHAR(50),
	@URL		VARCHAR(255)
AS
BEGIN
	/*
		Name 		:	RPT_MACQUARIE_PRODUCTION_OVERVIEW 
		Written On	:   09/11/2013 By Sudalai Mani
		Description	:	Produces data for Production Overview Report  		
	*/
    
    --Do we have a site
    IF DATALENGTH(RTRIM(@SITES)) = 0 
    BEGIN
		RAISERROR ('SITE IS REQUIRED', 16, 1)
		RETURN
    END

    --Do we have a type
    IF DATALENGTH(RTRIM(@TYPE)) = 0 
    BEGIN
		RAISERROR ('JOBTYPE IS REQUIRED', 16, 1)
		RETURN
    END

    --Do we have a start date
    IF @FROMDATE IS NULL
    BEGIN
		RAISERROR ('STARTING DATE IS REQUIRED', 16, 1)
		RETURN
    END

    --Do we have an end date
    IF @TODATE IS NULL
    BEGIN
		RAISERROR ('ENDING DATE IS REQUIRED', 16, 1)
		RETURN
    END

	--Check ALL site option
	IF LTRIM(RTRIM(@SITES)) = 'ALL' 
	BEGIN 
		--Do we have user name
		IF DATALENGTH(RTRIM(@USER)) = 0
		BEGIN 
			RAISERROR ('USER NAME IS REQUIRED', 16, 1)
			RETURN
		END 
		--get comma separated site name		
		SELECT	@SITES = COALESCE(@SITES + ',', '') + US.[SITE] 
		FROM	USER_SITES US WITH(NOLOCK) JOIN SITES S WITH(NOLOCK) ON S.[SITE] = US.[SITE]   
		WHERE	US.[USER] = @USER AND S.[ENABLED] = 1    		
	END
	
	SET @SITES = REPLACE(@SITES, '''', '')
	
	--Build a temp table based on the cost codes
	DECLARE @COLLINE	VARCHAR(MAX)
	DECLARE @SUMLINE	VARCHAR(MAX)
	DECLARE @TMP		VARCHAR(MAX)
	DECLARE @COLUMN		VARCHAR(MAX)

    DECLARE COLUMN_SOURCES CURSOR FAST_FORWARD FOR
		SELECT DISTINCT COST_CODE =  [DESCRIPTION] FROM COST_CODES WITH(NOLOCK) WHERE DBO.FN_INSTRING([SITE], @SITES, ',') = 1
	
	--Loop thru each item and build the query needed to create the temp table for holding the data used in this report
	CREATE TABLE #SQL 
	(
		[JOB TYPE]			VARCHAR(20) NULL DEFAULT '',		
		[COST CENTER OWNER]	VARCHAR(100) NULL,
		[GL4 COST CENTER]	VARCHAR(100) NULL,
		[PROJECT NAME]		VARCHAR(100) NULL,
		[PROJECT CODE]		VARCHAR(100) NULL,
		[GROUP]				VARCHAR(100) NULL,
		[DEPARTMENT]		VARCHAR(100) NULL,
		[DIVISION]			VARCHAR(100) NULL,
		[COMPLETED]			DATETIME NULL,
	    [JOB NO]			VARCHAR(20) NULL	    
	)
	
	SET @COLLINE = ''
	SET @SUMLINE = ''
	
	OPEN COLUMN_SOURCES
		FETCH NEXT FROM COLUMN_SOURCES INTO @COLUMN
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF DATALENGTH(RTRIM(@COLUMN)) > 0 
			BEGIN				
				SET @COLLINE = @COLLINE + ',[' + REPLACE(UPPER(@COLUMN), '''', '') + '],[' 
								--+ REPLACE(UPPER(@COLUMN), '''', '') + ' - COST],[' 
								+ REPLACE(UPPER(@COLUMN), '''', '') + ' - TOTAL COST]'				
				SET @SUMLINE = @SUMLINE + ',SUM([' + REPLACE(UPPER(@COLUMN), '''', '') + ']),SUM([' 
								--+ REPLACE(UPPER(@COLUMN), '''', '') + ' - COST]),SUM([' 
								+ REPLACE(UPPER(@COLUMN), '''', '') + ' - TOTAL COST])' 								
				SET @TMP = 'ALTER TABLE [#SQL] ADD [' + REPLACE(UPPER(@COLUMN), '''', '') + '] DECIMAL(18,0) NULL DEFAULT 0'
				EXEC UNI_EXECUTESQL @TMP
				SET @TMP = 'ALTER TABLE [#SQL] ADD [' + REPLACE(UPPER(@COLUMN), '''', '') + ' - COST] DECIMAL(18,2) NULL DEFAULT 0'
				EXEC UNI_EXECUTESQL @TMP
				SET @TMP = 'ALTER TABLE [#SQL] ADD [' + REPLACE(UPPER(@COLUMN), '''', '') + ' - TOTAL COST] DECIMAL(18,2) NULL DEFAULT 0'
				EXEC UNI_EXECUTESQL @TMP 				
			END
			FETCH NEXT FROM COLUMN_SOURCES INTO @COLUMN
		END

	CLOSE COLUMN_SOURCES
	DEALLOCATE COLUMN_SOURCES
	
	---- Add new column for Total Cost
	--ALTER TABLE [#SQL] ADD [TOTAL COST] DECIMAL (18, 2) DEFAULT 0
	--SET @COLLINE = @COLLINE + ',[TOTAL COST]'
	--SET @SUMLINE = @SUMLINE+ ',SUM([TOTAL COST])'	
	
	-- Create index for lookup
	CREATE NONCLUSTERED INDEX [IX_TEMP_SQL] ON #SQL
	(
		[JOB NO] ASC
	) WITH FILLFACTOR = 90 ON [PRIMARY]

	--Get jobs to process
    DECLARE JOB_DATA_SOURCE CURSOR FAST_FORWARD FOR
		SELECT	[JOB TYPE], [COST CENTER OWNER], [GL4 COST CENTER], [PROJECT NAME], [PROJECT CODE], [GROUP], DEPARTMENT, DIVISION, 
				COMPLETED, [JOB NO], COSTCODEID, COST_CODE, QUANTITY = SUM(QUANTITY), COST 
		FROM	(SELECT [JOB TYPE]			=	(CASE WHEN DATALENGTH(T.DISPLAY_CODE) > 0 THEN T.DISPLAY_CODE ELSE T.JOB_TYPE END),
						[COST CENTER OWNER]	=	J.REQUESTED_BY,
						[GL4 COST CENTER]	=	CLIENT + (CASE WHEN DATALENGTH(MATTER) > 0 THEN '.' + MATTER ELSE '' END),
						[PROJECT NAME]		=	J.TEXT02,
						[PROJECT CODE]		=	J.TEXT01,
						[GROUP]				=	J.JOB_GROUP,
						[DEPARTMENT]		=	J.DEPT001,
						[DIVISION]			=	J.TEXT03,						
						[COMPLETED]			=	J.COMPLETED,
						[JOB NO]			=	J.JOB_NO + '-' + J.JOB_SUB_NO,
						[COSTCODEID]		=	P.COST_CODE,
						[COST_CODE]			=	CC.[DESCRIPTION],
						[QUANTITY]			=	ISNULL(P.QUANTITY, 0),
						[COST]				=	ISNULL(CC.UNIT_COST, 0)
				FROM	VWJOBTICKETS J WITH(NOLOCK) LEFT OUTER HASH JOIN JOB_TICKET_Workflow P WITH(NOLOCK) 
						ON J.[SITE] = P.[SITE] AND J.JOB_NO = P.JOB_NO AND J.JOB_SUB_NO = P.JOB_SUB_NO 
						JOIN Cost_Codes CC WITH(NOLOCK) ON P.[SITE] = CC.[SITE] AND P.COST_CODE = CC.COST_CODE			
						JOIN JOB_TICKET_TYPES T WITH(NOLOCK) ON T.[SITE] = J.[SITE] AND T.JOB_NO = J.JOB_NO AND T.JOB_SUB_NO = J.JOB_SUB_NO 
				WHERE	J.[status] = 'COMPLETED' AND DBO.FN_INSTRING(J.[SITE], @SITES, ',') = 1
						AND J.JOB_TYPE LIKE @TYPE AND J.COMPLETED BETWEEN @FROMDATE AND @TODATE AND P.COST_CODE <> 'QC' AND P.COST_CODE <> 'DELIVERY'
				) results
		GROUP BY [JOB TYPE], [COST CENTER OWNER], [GL4 COST CENTER], [PROJECT NAME], [PROJECT CODE], [GROUP], DEPARTMENT, DIVISION,
				COMPLETED, [JOB NO], COSTCODEID, COST_CODE, COST
	  
	--Loop thru jobs and build results list
	DECLARE	@TJOBTYPE			VARCHAR(20)
	DECLARE	@TCOSTCENTEROWNER	VARCHAR(100)
	DECLARE	@TGL4COSTCENTER		VARCHAR(100)
	DECLARE	@TPROJECTNAME		VARCHAR(100)
	DECLARE	@TPROJECTCODE		VARCHAR(100)
	DECLARE	@TGROUP				VARCHAR(100)
	DECLARE	@TDEPARTMENT		VARCHAR(100)
	DECLARE	@TDIVISION			VARCHAR(100)
    DECLARE	@TCOMPLETED			DATETIME
    DECLARE	@TJOBNO				VARCHAR(20)
    DECLARE @COSTCODEID			VARCHAR(10)
    DECLARE @TCOST_CODE			VARCHAR(50)
	DECLARE @TQUANTITY			DECIMAL(10, 0)
	DECLARE @TCOST				DECIMAL(18, 2)
	DECLARE @OJOBTYPE			VARCHAR(20)

	OPEN JOB_DATA_SOURCE
		FETCH NEXT FROM JOB_DATA_SOURCE INTO @TJOBTYPE, @TCOSTCENTEROWNER, @TGL4COSTCENTER, @TPROJECTNAME, @TPROJECTCODE, @TGROUP, @TDEPARTMENT, 
										@TDIVISION, @TCOMPLETED, @TJOBNO, @COSTCODEID, @TCOST_CODE, @TQUANTITY, @TCOST
		SET @OJOBTYPE = @TJOBTYPE
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Did the job type change?
			IF @OJOBTYPE <> @TJOBTYPE
			BEGIN 
				--Yes, we will need a summary line
				SET @TMP = 'INSERT INTO #SQL ([JOB TYPE]' + @COLLINE + ')' + CHAR(13) + CHAR(10)
				SET @TMP = @TMP + ' SELECT ''Sub Total - ' + @OJOBTYPE + '''' + @SUMLINE + ' FROM #SQL WHERE [JOB TYPE] = ''' + @OJOBTYPE + ''''
				EXEC UNI_EXECUTESQL @TMP
				SET @OJOBTYPE = @TJOBTYPE
			END

			--Insert a record for the job number if non is present
			IF NOT EXISTS(SELECT [JOB NO] FROM [#SQL] WHERE [JOB NO] = @TJOBNO)
			BEGIN 
				INSERT INTO #SQL ([JOB TYPE], [COST CENTER OWNER], [GL4 COST CENTER], [PROJECT NAME], [PROJECT CODE], [GROUP], 
									[DEPARTMENT], [DIVISION], [COMPLETED], [JOB NO]) 
				VALUES (@TJOBTYPE, @TCOSTCENTEROWNER, @TGL4COSTCENTER, @TPROJECTNAME, @TPROJECTCODE, @TGROUP, 
						@TDEPARTMENT, @TDIVISION, @TCOMPLETED, @TJOBNO) 
			END 
	 
	    
			--Build update query base on step name
			SET @TMP = 'UPDATE #SQL SET [' + @TCOST_CODE + '] = ISNULL([' + @TCOST_CODE + '], 0) + ' + CONVERT(VARCHAR(20), @TQUANTITY) 
			SET @TMP =	@TMP + ', [' + REPLACE(@TCOST_CODE, '''', '') + ' - COST] = ISNULL([' + REPLACE(@TCOST_CODE, '''', '') + ' - COST], 0) + ' 
							+ CONVERT(VARCHAR(20), @TCOST) 
			SET @TMP =	@TMP + ', [' + REPLACE(@TCOST_CODE, '''', '') + ' - TOTAL COST] = ISNULL([' + REPLACE(@TCOST_CODE, '''', '') + ' - TOTAL COST], 0) + ' 
							+ CONVERT(VARCHAR(20), @TCOST * @TQUANTITY) 
			--SET @TMP =	@TMP + ', [TOTAL COST] = [TOTAL COST] + ISNULL([' + REPLACE(@TCOST_CODE, '''', '') + ' - COST], 0) + ' + CONVERT(VARCHAR(20), @TCOST) 
			SET @TMP = @TMP + ' WHERE [JOB NO] = ''' + @TJOBNO + ''''
			EXEC UNI_EXECUTESQL @TMP
				
			FETCH NEXT FROM JOB_DATA_SOURCE INTO @TJOBTYPE, @TCOSTCENTEROWNER, @TGL4COSTCENTER, @TPROJECTNAME, @TPROJECTCODE, @TGROUP, @TDEPARTMENT, 
										@TDIVISION, @TCOMPLETED, @TJOBNO, @COSTCODEID, @TCOST_CODE, @TQUANTITY, @TCOST
		END
	
	CLOSE JOB_DATA_SOURCE
	DEALLOCATE JOB_DATA_SOURCE

	--Execute last summary line for job type
	SET @TMP = 'INSERT INTO #SQL ([JOB TYPE]' + @COLLINE + ')' + CHAR(13) + CHAR(10)
	SET @TMP = @TMP + ' SELECT ''Sub Total - ' + @OJOBTYPE + '''' + @SUMLINE + ' FROM #SQL WHERE [JOB TYPE] = ''' + @OJOBTYPE + ''''
	EXEC UNI_EXECUTESQL @TMP

	--Execute grand totals
	SET @TMP = 'INSERT INTO #SQL ([JOB TYPE]' + @COLLINE + ')' + CHAR(13) + CHAR(10)
	SET @TMP = @TMP + ' SELECT ''Grand Total''' + @SUMLINE + ' FROM #SQL WHERE NOT [JOB TYPE] LIKE ''Sub Total -%'''
	EXEC UNI_EXECUTESQL @TMP			
   	
	SELECT * FROM #SQL
	DROP TABLE #SQL

END

GO


GO
ALTER PROCEDURE [dbo].[RPT_RBS_JOB_DETAILS]
	@SITES		VARCHAR(1024),
	@TYPE		VARCHAR(20),
	@FROMDATE	DATETIME,
	@TODATE		DATETIME,
	@EXPORT		BIT,
	@USER		VARCHAR(20),
	@URL		VARCHAR(255)
AS
BEGIN
	/*
		Name		:   RPT_RBS_JOB_DETAILS
		Written On	:   04/10/2013 By Srinivasan
		Description	:   Produces data for the given date range
		Updated On	:	06/25/2013 By Sudalai Mani - cost centre column added
		
		Updated On	:   30/07/2013 By Ramkumar
		Description	:   1. Replace column 9 'Business Unit' with the following:
						"Country"  = sourced FROM REQUESTORS.CUSTOM01 field
						Can you please confirm the content CUSTOM01 field. This should have values like "US, GB, IN" - please confirm this before making the change. 

						2. Add column "Created Date" = sourced FROM vwjobticketS.CREATED  which is the system creation datetime.
						Add this column after the 'Requested Date' column. 
		Updated On	:	08/29/2013 By Srinivasan, Removed Work Type column & resolved duplicate issue				
	*/
	

	--- Test Data Start
	--DECLARE @SITES		NVARCHAR (1024) = 'NY'
	--DECLARE @FROMDATE	DATETIME = '2013-01-03 01:05:00.000'
	--DECLARE @TODATE		DATETIME = '2013-01-05 01:05:00.000'
	--DECLARE @EXPORT		BIT = ''
	--DECLARE @USER		NVARCHAR(20) = ''
	--DECLARE @URL		NVARCHAR(255) = ''
	--- Test Data End

	--Do we have a site
	IF DATALENGTH(RTRIM(@SITES)) = 0 
	BEGIN
		RAISERROR ('SITE IS REQUIRED', 16, 1)
		RETURN
	END

	--Do we have a start date
	IF @FROMDATE IS NULL
	BEGIN
		RAISERROR ('STARTING DATE IS REQUIRED', 16, 1)
		RETURN
	END

	--Do we have an end date
	IF @TODATE IS NULL
	BEGIN
		RAISERROR ('ENDING DATE IS REQUIRED', 16, 1)
		RETURN
	END

	SET @SITES = REPLACE(@SITES, '''','')
	
	IF @EXPORT  = 1
	BEGIN
		SELECT	[Parent Site]				=	j.parent_site, 
				[Job#]						=	j.job_no, 
				[Job Type]					=	j.job_type,
				[Client#]					=	j.text03,
				[Requestor]					=	j.requested_by, 
				[Cost Centre Code]			=	R.practicegroup, 
				[Cost Centre Desc Finance]	=	R.department, 
				[Cost Centre Desc HR]		=	R.custom03, 
				[Country]					=	R.custom01, 
				[Requested Date]			=	j.requested_date,
				[Created Date]				=	j.CREATED,
				[Project#]					=	j.alt02, 
				[Title]						=	j.job_title,
				[No of Copies]				=	j.NO_BOXES,
				[No of Pages]				=	j.NO_SETS,
				[Task#]						=	w.step_no, 
				[Location]					=	s.site_name, 
				--[Work Type]				=	o.[option],
				[Task name]					=	w.step_name, 
				[Cost code]					=	w.cost_code, 
				[Operator Name]				=	dbo.fn_getpersonnelname(w.personnel), 
				[Operator Start]			=	w.[started], 
				[Operator Stop]				=	w.completed,
				[Hours]						=	w.[hours],
				[Total Units]				=	CAST(w.quantity AS DECIMAL(9, 0))
		FROM	vwjobtickets J WITH(NOLOCK) JOIN job_ticket_workflow W WITH(NOLOCK) ON j.[site] = w.[site] AND j.job_no = w.job_no 
				JOIN SITES S WITH(NOLOCK) ON j.[site] = s.[site] 
				LEFT JOIN REQUESTORS R WITH(NOLOCK) ON J.REQUESTED_BY = R.LAST_NAME + ','+ R.FIRST_NAME AND R.FIRMNO = J.TIMEKEEPER
				--LEFT JOIN job_ticket_options o WITH(NOLOCK) ON o.[site] = j.[site] AND o.job_no = j.job_no 
				--AND o.category = 'Work Types' AND o.value = 'on'
		WHERE	J.REQUESTED_DATE BETWEEN @FROMDATE AND @TODATE AND j.[status] = 'completed' AND DBO.FN_INSTRING(j.parent_site, @SITES, ',') = 1
		ORDER BY j.alt02, j.job_no
	END
	ELSE 	
	BEGIN 
		CREATE TABLE #RESULTTABLE
		(
			[ID]						INT IDENTITY(1, 1),
			[Parent Site]				VARCHAR(50), 
			[Job#]						VARCHAR(50), 
			[Job Type]					VARCHAR(50),
			[Client#]					VARCHAR(50),
			[Requestor]					VARCHAR(50), 
			[Cost Centre Code]			VARCHAR(50),
			[Cost Centre Desc Finance]	VARCHAR(50),
			[Cost Centre Desc HR]		VARCHAR(50),
			[Country]					VARCHAR(50),
			[Requested Date]			DATETIME,
			[Project#]					VARCHAR(50),
			[Title]						VARCHAR(80),
			[No of Copies]				VARCHAR(50),
			[No of Pages]				VARCHAR(50),
			[Task#]						VARCHAR(50), 
			[Location]					VARCHAR(100), 
			--[Work Type]					VARCHAR(50),
			[Task Name]					VARCHAR(50), 
			[Cost Code]					VARCHAR(50),
			[Operator Name]				VARCHAR(100),
			[Operator Start]			DATETIME, 
			[Operator Stop]				DATETIME, 
			[Hours]						DECIMAL(9, 2),
			[Total Units]				DECIMAL(9, 0),
			[Created Date]				DATETIME
		)

		-- CURSOR TO FETCH SOURCE ROWS
		DECLARE RESULTCUR CURSOR LOCAL FOR 
		SELECT	[Parent Site]				=	j.parent_site, 
				[Job#]						=	j.job_no, 
				[Job Type]					=	j.job_type,
				[Client#]					=	j.text03,
				[Requestor]					=	j.requested_by, 
				[Cost Centre Code]			=	R.practicegroup, 
				[Cost Centre Desc Finance]	=	R.department, 
				[Cost Centre Desc HR]		=	R.custom03, 
				[Country]					=	R.custom01, 
				[Requested Date]			=	j.requested_date,
				[Project#]					=	j.alt02, 
				[Title]						=	j.job_title,
				[No of Copies]				=	j.NO_BOXES,
				[No of Pages]				=	j.NO_SETS,
				[Task#]						=	w.step_no, 
				[Location]					=	s.site_name, 
				--[Work Type]					=	o.[option],
				[Task name]					=	w.step_name, 
				[Cost code]					=	w.cost_code, 
				[Operator Name]				=	dbo.fn_getpersonnelname(w.personnel), 
				[Operator Start]			=	w.[started], 
				[Operator Stop]				=	w.completed,
				[Hours]						=	w.[hours],
				[Total Units]				=	w.quantity ,
				[Created Date]		= J.CREATED
		FROM	vwjobtickets J WITH(NOLOCK) JOIN job_ticket_workflow W WITH(NOLOCK) ON j.[site] = w.[site] AND j.job_no = w.job_no
				JOIN SITES S WITH(NOLOCK) ON j.[site] = s.[site] 
				LEFT JOIN REQUESTORS R WITH(NOLOCK) ON J.REQUESTED_BY = R.LAST_NAME + ','+ R.FIRST_NAME AND R.FIRMNO = J.TIMEKEEPER
				--LEFT JOIN job_ticket_options o WITH(NOLOCK) ON o.[site] = j.[site] AND o.job_no = j.job_no 
				--AND o.category = 'Work Types' AND o.value = 'on'
		WHERE	J.REQUESTED_DATE BETWEEN @FROMDATE AND @TODATE AND j.[status] = 'completed' AND DBO.FN_INSTRING(j.parent_site, @SITES, ',') = 1
		ORDER BY j.alt02, j.job_no
		
		DECLARE @CParentSite		VARCHAR(50) 
		DECLARE @Jobno				VARCHAR(50) 
		DECLARE @JobType			VARCHAR(50)
		DECLARE @Client				VARCHAR(50)
		DECLARE @Requestor			VARCHAR(50)
		DECLARE @CostCentre			VARCHAR(50)
		DECLARE @CostFinance		VARCHAR(50)
		DECLARE @CostHR				VARCHAR(50)
		DECLARE @Country			VARCHAR(50)
		DECLARE @RequestedDate		DATETIME
		DECLARE @Project			VARCHAR(50)
		DECLARE @CTITLE				VARCHAR(80)
		DECLARE @NoofCopies			VARCHAR(50)
		DECLARE @NoofPages			VARCHAR(50)
		DECLARE @Task				VARCHAR(50)
		DECLARE @Location			VARCHAR(100)
		--DECLARE @WorkType			VARCHAR(50)
		DECLARE @Taskname			VARCHAR(50) 
		DECLARE @Costcode			VARCHAR(50)
		DECLARE @OperatorName		VARCHAR(100)
		DECLARE @OperatorStart		DATETIME
		DECLARE @OperatorStop		DATETIME 
		DECLARE @Hours				DECIMAL(9, 2)
		DECLARE @TotalUnits			DECIMAL(9, 0)
		DECLARE @CreatedDate		DATETIME 
			
		OPEN RESULTCUR
		FETCH NEXT FROM RESULTCUR INTO @CParentSite, @Jobno, @JobType, @Client, @Requestor, @CostCentre, @CostFinance, @CostHR, @Country, 
						@RequestedDate, @Project, @CTITLE, @NoofCopies, @NoofPages, @Task, @Location, @Taskname, @Costcode, @OperatorName, 
						@OperatorStart, @OperatorStop, @Hours, @TotalUnits, @CreatedDate
		
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM #RESULTTABLE WHERE [Job#] = @jobno)
			BEGIN
				INSERT INTO #RESULTTABLE 
				(
					[Parent Site], [Job#], [Job Type], [Client#], [Requestor], [Cost Centre Code], [Cost Centre Desc Finance], [Cost Centre Desc HR], 
					[Country], [Requested Date], [Created Date], [Project#], [Title], [No of Copies], [No of Pages]
				)
				SELECT	@CParentSite, @Jobno, @JobType, @Client, @Requestor, @CostCentre, @CostFinance, @CostHR, @Country, 
						@RequestedDate, @CreatedDate, @Project, @CTITLE, @NoofCopies, @NoofPages
			END
				
				INSERT INTO #RESULTTABLE 
				(
					[Task#], [Location], [Task name], [Cost code], [Operator Name], [Operator Start], [Operator Stop], [Hours], [Total Units]
				)
				SELECT @Task, @Location, @Taskname, @Costcode, @OperatorName, @OperatorStart, @OperatorStop, @Hours, @TotalUnits
		
			FETCH NEXT FROM RESULTCUR INTO @CParentSite, @Jobno, @JobType, @Client, @Requestor, @CostCentre, @CostFinance, @CostHR, @Country, 
						@RequestedDate, @Project, @CTITLE, @NoofCopies, @NoofPages, @Task, @Location, @Taskname, @Costcode, @OperatorName, 
						@OperatorStart, @OperatorStop, @Hours, @TotalUnits, @CreatedDate
		
		END
		
		CLOSE RESULTCUR
		DEALLOCATE RESULTCUR
		
		SELECT	[Parent Site], [Job#], [Job Type], [Client#], [Requestor], [Cost Centre Code], [Cost Centre Desc Finance], 
				[Cost Centre Desc HR], [Country], [Requested Date], [Created Date], [Project#], [Title], [No of Copies], [No of Pages], [Task#], 
				[Location], [Task name], [Cost Code], [Operator Name], [Operator Start], [Operator Stop], [Hours], [Total Units]
		FROM #RESULTTABLE 
			ORDER BY ID

		DROP TABLE #RESULTTABLE
	END	
END

GO


GO 

CREATE PROCEDURE [dbo].[RPT_HUMANA_PRINT_BILLING_GREENBAY]
	@SITES		VARCHAR(1024),
	@JOBTYPE	VARCHAR(20),
	@FROMDATE	DATETIME,
	@TODATE		DATETIME,
	@USER		VARCHAR(50),
	@URL		VARCHAR(255)
AS
BEGIN
	/*
		Name       :	RPT_HUMANA_PRINT_BILLING_GREENBAY
		Description:	Created a separate Stored Procedure for Greenbay site for HUMANA client. This is created as per the 
						the Change 68634 filed on 6/13/2013.
						The following are the changes carried out to the earlier SP RPT_HUMANA_PRINT_BILLING:
						  1. Removed [BILL_TO_EMAIL] field
						  2. Removed [JOB_NUMBER] field.
						  3. Added a new field [MISCELLANEOUS AMOUNT]. This field would show the Total Price field of the Job. 
							 This is the field [VALUE01] in the database. This field would be shown for the Step No 10106 
							 and 10119.
						  4. The earlier Stored Procedure was selecting Jobs of all statuses. This Stored Procedure would 
							 select the Jobs which are not cancelled. Hence added a condition STATUS <> 'CANCELLED'.
		Written On :	06/20/2013
		Written By :	Srivatsan.S
		Modified On:	31/07/2013
		Modified By:	Srivatsan.S
		Description:	Based on the Ticket : 69468, the following modifications were performed:		 
						  1. The Query and J.STATUS <>'CANCELLED' was modified as and J.STATUS = 'COMPLETED'.
						  2. The [MISCELLANEOUS AMOUNT] column was commented.
						  3. The @UNIT_MEASUREMENT table was modified to include two columns :	UNIT AND AMOUNT. 
						      By default NULL was inserted in these fields. 
						  4. The details inserted into the table were modified as per the details 
						     given in the Excel sheet along with the ticket.The existing Service Codes were 
							 modified and the new codes were added to the list.		
	*/
   
	--Do we have a site
	IF DATALENGTH(RTRIM(@SITES)) = 0 
	BEGIN
		RAISERROR ('SITE IS REQUIRED', 16, 1)
		RETURN
	END
	
	--DO WE HAVE A JOBTYPE
	IF DATALENGTH(RTRIM(@JOBTYPE)) = 0 
	BEGIN
		RAISERROR ('JOBTYPE IS REQUIRED', 16, 1)
		RETURN
	END
   
	--Do we have a startdate
	IF @FROMDATE IS NULL
	BEGIN
		RAISERROR ('STARTING DATE IS REQUIRED', 16, 1)
		RETURN
	END

	--Do we have an endate
	IF @TODATE IS NULL
	BEGIN
		RAISERROR ('ENDING DATE IS REQUIRED', 16, 1)
		RETURN
	END
	
	SET @SITES = REPLACE(@SITES, '''', '')
		
	-- Table variable to hold Billing Info
	DECLARE @BILLING_INFO AS TABLE
	(
		[SITE]				VARCHAR(20),
		ISA_CONTRACT		VARCHAR(20),
		BILLING_COMPANY		VARCHAR(10),
		BILLING_DEPARTMENT	VARCHAR(10),
		BILLING_FACILITY	VARCHAR(10),
		BILL_TO_EMAIL		VARCHAR(10)
	)

	-- Table variable to hold unit measurement
	DECLARE @UNIT_MEASUREMENT AS TABLE
	(
		[Cost_Code]				VARCHAR(20),
		[Description]			VARCHAR(100),
		[Unit_Cost]				DECIMAL(18, 3),
		Unit_Measurement		VARCHAR(20),
		Service_Type			VARCHAR(20),
		Units					INT		   ,
		Amount					DECIMAL(18, 3)
	)
	
	-- Inserting Billing Info
	INSERT INTO @BILLING_INFO ([SITE], ISA_CONTRACT, BILLING_COMPANY, BILLING_DEPARTMENT, BILLING_FACILITY, BILL_TO_EMAIL)
	SELECT 	'CHICAGO',		'Chicago',			'004',		'11243',	'01855',	'BLANK'	UNION ALL 
	SELECT	'CINCINNATI',	'Cincinnati',		'004',		'11243',	'01988',	'BLANK'	UNION ALL 
	SELECT 	'GREENBAY',		'Green Bay',		'004',		'11243',	'01002',	'BLANK'	UNION ALL 
	SELECT 	'JAX',			'Jacksonville',		'004',		'11243',	'02166',	'BLANK'	UNION ALL 
	SELECT 	'LANCASTER',	'Lancaster',		'004',		'11243',	'02081',	'BLANK'	UNION ALL 
	SELECT 	'LOUIS-CORP',	'Louisville CORP',	'004',		'11243',	'01001',	'BLANK'	UNION ALL 
	SELECT 	'LOUISV-WTS',	'Louisville WTS',	'004',		'11243',	'01004',	'BLANK'	UNION ALL 
	SELECT 	'MIRAMAR',		'Miramar',			'004',		'11243',	'01584',	'BLANK'	UNION ALL 
	SELECT 	'PHOENIX',		'Phoenix',			'004',		'11243',	'01833',	'BLANK'	UNION ALL 
	SELECT 	'TAMPA-LINC',	'Tampa MetWest',	'004',		'11243',	'02326',	'BLANK'	UNION ALL 
	SELECT 	'TAMPA-NETP',	'Tampa NetPark',	'004',		'11243',	'01779',	'BLANK'	UNION ALL 
	SELECT 	'WAUKESHA',		'Waukesha',			'004',		'11243',	'01659',	'BLANK'
	
	-- Inserting Unit Measurement Info
	INSERT INTO @UNIT_MEASUREMENT ([Cost_Code], [Description], [Unit_Cost], Unit_Measurement, Service_Type, Units, Amount)
	SELECT 				'COILBIND',		'BINDING: COIL',					'0.2',		'per book',			'Binding',NULL,NULL 
	UNION ALL SELECT 	'COMB-GBC',		'BINDING: GBC/COMB',				'0.2',		'per book',			'Binding',NULL,NULL
	UNION ALL SELECT 	'SADDLESTIT',	'BINDING: SADDLE STITCH',			'0',		'',					'Binding',NULL,NULL
	UNION ALL SELECT 	'TAPEBIND',		'BINDING: TAPE',					'0.2',		'per book',			'Binding',NULL,NULL
	UNION ALL SELECT 	'BW',			'BLACK AND WHITE',					'0.026',	'per impression',	'Printing',NULL,NULL
	UNION ALL SELECT 	'BLACKBACK',	'BLACK BACK',						'0.02',		'per book',			'Binding',NULL,NULL
	UNION ALL SELECT 	'COVERSTOCK',	'CARD STOCK',						'0.02',		'per sheet',		'paper',NULL,NULL
	UNION ALL SELECT 	'CLEARCOVER',	'CLEAR COVER',						'0.2',		'per book',			'Binding',NULL,NULL
	UNION ALL SELECT 	'COLLATE',		'COLLATE',							'0',		'',					'',NULL,NULL
	UNION ALL SELECT 	'COLOR',		'COLOR',							'0.089',	'per impression',	'Printing',NULL,NULL
	UNION ALL SELECT 	'CUT',			'CUT',								'0',		'per sheet',		'Cutting',1,0
	UNION ALL SELECT 	'DRILLING',		'DRILLING',							'0',		'per unit',			'Drilling',1,0
	UNION ALL SELECT 	'GBFBTY2430',	'FOAMBOARD: GB SPECIALTY 24X30',	'8.55',		'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'GBFBTY3040',	'FOAMBOARD: GB SPECIALTY 30X40',	'18.37',	'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'GBFBST2430',	'FOAMBOARD: GB STANDARD 24X30',		'7.7',		'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'GBFBST3040',	'FOAMBOARD: GB STANDARD 30X40',		'16.96',	'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'LOUFB2030',	'FOAMBOARD: LOUISVILLE 20X30',		'6.58',		'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'LOUFB2436',	'FOAMBOARD: LOUISVILLE 24X36',		'9.8',		'per board',		'Mounting',NULL,NULL
	UNION ALL SELECT 	'FOLD',			'FOLD',								'0',		'per sheet',		'Folding',1,0
	UNION ALL SELECT 	'INSERTING',	'INSERTING',						'0',		'per unit',			'Inserting',1,0
	UNION ALL SELECT 	'LAMINATE',		'LAMINATING',						'0.43',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'LAM-CARD',		'LAMINATION: BUSINESS CARD',		'0.04',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'LAM-CUSTOM',	'LAMINATION: CUSTOM',				'0',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'LAM-LEGAL',	'LAMINATION: LEGAL SIZE',			'0.13',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'LAM-LETTER',	'LAMINATION: LETTER SIZE',			'0.1',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'LAM-MENU',		'LAMINATION: MENU SIZE',			'0.2',		'per sheet',		'Laminating',NULL,NULL
	UNION ALL SELECT 	'MAILING',		'MAILING',							'0',		'',					''			,NULL,NULL
	UNION ALL SELECT 	'OTHER',		'OTHER',							'0',		'',					''			,NULL,NULL
	UNION ALL SELECT 	'OT-HOLIDAY',	'OVERTIME: HOLIDAY',				'44',		'per hour',			'Labor',NULL,NULL
	UNION ALL SELECT 	'OT-WEEKDAY',	'OVERTIME: WEEKDAY',				'27',		'per hour',			'Labor',NULL,NULL
	UNION ALL SELECT 	'OT-WEEKEND',	'OVERTIME: WEEKEND',				'35',		'per hour',			'Labor',NULL,NULL
	UNION ALL SELECT 	'11X17',		'PAPER: 11X17',						'0.018',	'per sheet',		'paper',NULL,NULL
	UNION ALL SELECT 	'11X17CARD',	'PAPER: 11X17 CARD STOCK',			'0.078',	'per sheet',		'paper',NULL,NULL
	UNION ALL SELECT 	'CARDSTOCK',	'PAPER: CARD STOCK',				'0.02',		'per sheet',		'paper',NULL,NULL
	UNION ALL SELECT 	'STANDARD',		'PAPER: STANDARD LETTER & LEGAL',	'0.009',	'per sheet',		'paper',NULL,NULL
	UNION ALL SELECT 	'POSTER',		'POSTER',							'2',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOULAMINAT',	'POSTER LAMINATION: LOUISVILLE',	'0',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSPE24X30',	'POSTER: GB SPECIALTY 24X30',		'2.45',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSPE24X36',	'POSTER: GB SPECIALTY 24X36',		'2.94',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSPE24X40',	'POSTER: GB SPECIALTY 24X40',		'3.27',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSPE30X40',	'POSTER: GB SPECIALTY 30X40',		'4.08',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSTD24X30',	'POSTER: GB STD 24X30',				'1.6',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSTD24X36',	'POSTER: GB STD 24X36',				'1.92',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSTD24X40',	'POSTER: GB STD 24X40',				'2.13',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'GBSTD30X40',	'POSTER: GB STD 30X40',				'2.67',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOUSTD',		'POSTER: LOUISVILLE 16X20',			'1.33',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOUSTD18X2',	'POSTER: LOUISVILLE 18X24',			'1.8',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOUSTD20X3',	'POSTER: LOUISVILLE 20X30',			'2.5',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOUSTD24X3',	'POSTER: LOUISVILLE 24X36',			'3.6',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'LOUSTD36X5',	'POSTER: LOUISVILLE 36X52',			'7.8',		'per poster',		'Printing',NULL,NULL
	UNION ALL SELECT 	'SCANNING',		'SCANNING',							'0',		'per sheet',		'Scanning',1,0
	UNION ALL SELECT 	'STAPLED',		'STAPLED',							'0',		'per unit',			'Stapling',1,0
	UNION ALL SELECT 	'TAB',			'TABS',								'0.25',		'per set (5)',		'Binding',NULL,NULL
	UNION ALL SELECT 	'PAD',			'PADDING',							'0',		'per pad',			'Padding',1,0
	UNION ALL SELECT 	'POD11X17',		'PAPER: 11X17 POD',					'0',		'per sheet',		'Paper',1,0
	UNION ALL SELECT 	'POD85X11',		'PAPER: 8.5X11 POD',				'0',		'per sheet',		'Paper',1,0

	IF @JOBTYPE = '%' 
	BEGIN
		SELECT	[ISA_CONTRACT]					=	B.[ISA_CONTRACT],
				[BILLING_COMPANY]				=	B.[BILLING_COMPANY],
				[BILLING_DEPARTMENT]			=	B.[BILLING_DEPARTMENT],
				[BILLING_FACILITY]				=	B.[BILLING_FACILITY],
				[RECEIVING_COMPANY]				=	J.CLIENT,
				[RECEIVING_DEPARTMENT]			=	J.DEPT001,
				[RECEIVING_FACILITY]			=	J.DEPARTMENT,
				[RECEIVING_MARKET]				=	J.REQUESTOR_NAME,
				[RECEIVING_PRODUCT]				=	0,
				[RECEIVING_SEGMENT]				=	0,
				[REQUESTOR_NAME]				=	J.REQUESTED_BY,
				[REQUESTOR_EMAIL]				=	J.EMAIL,
				[REQUEST_DATE]					=	CONVERT(VARCHAR(10), J.REQUESTED_DATE, 110),
				[JOB_TYPE]						=	J.JOB_TITLE,
				[SERVICE_DETAIL_DESCRIPTION]	=	CC.[DESCRIPTION],
				[SERVICE_CODE]					=	CC.[COST_CODE],
				[SERVICE_TYPE]					=	U.SERVICE_TYPE,
				[UNIT_MEASUREMENT]				=	U.UNIT_MEASUREMENT,
				[PRICE_PER_UNIT]				=	U.UNIT_COST,
				[UNITS]							=	CASE WHEN U.SERVICE_TYPE = 'PRINTING' THEN 
													ISNULL(W.QUANTITY + W.WASTE_METER, 0) 
													ELSE ISNULL(W.QUANTITY, 0) END,
				[AMOUNT]						=	CASE WHEN J.JOB_TYPE = 'POSTERNEW' AND CC.[DESCRIPTION] = 'OTHER' AND W.VALUE01 <> '' THEN W.VALUE01
													WHEN W.STEP_NAME = 'Green Bay Other' AND W.VALUE01 <> '' THEN W.VALUE01
													WHEN U.SERVICE_TYPE  = 'PRINTING' THEN CAST((W.QUANTITY + W.WASTE_METER) * U.UNIT_COST AS NUMERIC(18, 3))													
													ELSE CAST(W.QUANTITY * U.UNIT_COST AS NUMERIC(18, 3)) END
		FROM	VWJOBTICKETS J WITH(NOLOCK) INNER HASH JOIN JOB_TICKET_WORKFLOW W WITH(NOLOCK) 
				ON J.[SITE] = W.[SITE] AND J.JOB_NO = W.JOB_NO AND J.JOB_SUB_NO = W.JOB_SUB_NO
				INNER JOIN COST_CODES CC WITH(NOLOCK) ON J.[SITE] = CC.[SITE]  AND W.COST_CODE = CC.COST_CODE 			
				LEFT OUTER JOIN @BILLING_INFO B ON J.[SITE] = B.[SITE] 
				LEFT OUTER JOIN @UNIT_MEASUREMENT U ON W.COST_CODE = U.COST_CODE 
		WHERE	J.COMPLETED BETWEEN @FROMDATE AND @TODATE AND DBO.FN_INSTRING(J.[SITE], @SITES, ',') = 1 
				AND J.JOB_TYPE IN ('POSTERNEW', 'PRINT-POD', 'PRINTS') AND J.[STATUS] = 'COMPLETED'
	END
	ELSE 
	BEGIN
		SELECT	[ISA_CONTRACT]					=	B.[ISA_CONTRACT],
				[BILLING_COMPANY]				=	B.[BILLING_COMPANY],
				[BILLING_DEPARTMENT]			=	B.[BILLING_DEPARTMENT],
				[BILLING_FACILITY]				=	B.[BILLING_FACILITY],
				[RECEIVING_COMPANY]				=	J.CLIENT,
				[RECEIVING_DEPARTMENT]			=	J.DEPT001,
				[RECEIVING_FACILITY]			=	J.DEPARTMENT,
				[RECEIVING_MARKET]				=	J.REQUESTOR_NAME,
				[RECEIVING_PRODUCT]				=	0,
				[RECEIVING_SEGMENT]				=	0,
				[REQUESTOR_NAME]				=	J.REQUESTED_BY,
				[REQUESTOR_EMAIL]				=	J.EMAIL,
				[REQUEST_DATE]					=	CONVERT(VARCHAR(10), J.REQUESTED_DATE, 110),
				[JOB_TYPE]						=	J.JOB_TITLE,
				[SERVICE_DETAIL_DESCRIPTION]	=	CC.[DESCRIPTION],
				[SERVICE_CODE]					=	CC.[COST_CODE],
				[SERVICE_TYPE]					=	U.SERVICE_TYPE,
				[UNIT_MEASUREMENT]				=	U.UNIT_MEASUREMENT,
				[PRICE_PER_UNIT]				=	U.UNIT_COST,
				[UNITS]							=	CASE WHEN U.SERVICE_TYPE = 'PRINTING' THEN ISNULL(W.QUANTITY + W.WASTE_METER, 0) 
													ELSE ISNULL(W.QUANTITY, 0) END,
				[AMOUNT]						=	CASE WHEN J.JOB_TYPE = 'POSTERNEW' AND CC.[DESCRIPTION] = 'OTHER' AND W.VALUE01 <> '' THEN W.VALUE01
													WHEN W.STEP_NAME = 'Green Bay Other' AND W.VALUE01 <> '' THEN W.VALUE01
													WHEN U.SERVICE_TYPE = 'PRINTING' THEN CAST((W.QUANTITY + W.WASTE_METER) * U.UNIT_COST AS NUMERIC(18, 3))
													ELSE CAST(W.QUANTITY * U.UNIT_COST AS NUMERIC(18, 3)) END
		FROM	VWJOBTICKETS J WITH(NOLOCK) INNER HASH JOIN JOB_TICKET_WORKFLOW W WITH(NOLOCK) 
				ON J.[SITE] = W.[SITE] AND J.JOB_NO = W.JOB_NO AND J.JOB_SUB_NO = W.JOB_SUB_NO
				INNER JOIN COST_CODES CC WITH(NOLOCK) ON J.[SITE] = CC.[SITE]  AND W.COST_CODE = CC.COST_CODE 			
				LEFT OUTER JOIN @BILLING_INFO B ON J.[SITE] = B.[SITE] 
				LEFT OUTER JOIN @UNIT_MEASUREMENT U ON W.COST_CODE = U.COST_CODE 
		WHERE	J.COMPLETED BETWEEN @FROMDATE AND @TODATE AND DBO.FN_INSTRING(J.[SITE], @SITES, ',') = 1 
				AND J.JOB_TYPE LIKE @JOBTYPE AND J.[STATUS] = 'COMPLETED'			
	END
	
END

GO

EXEC UNI_INSERT_FEEDBACK_LEGEND 
"1 - Very Poor | 2 - Poor | 3 - Good | 4 - Very Good | 5 � Excellent", "enterpriseapps@williamslea.com","888-999-1230, dial 1 then dial 5"
GO

EXEC UNI_INSERT_SITE_WARNING_MESSAGES
GO

